#!/bin/bash
# ===================================================================
# Script para ejecutar el análisis de métricas JTL - MediPlus
# Versión corregida con detección automática de JAR
# ===================================================================

set -e

# ===================================================================
# CONFIGURACIÓN Y DETECCIÓN AUTOMÁTICA
# ===================================================================

# Función para detectar automáticamente el JAR disponible
detectar_jar() {
    # Buscar en el directorio actual primero
    if [[ -f "pruebas-api-mediplus-1.0.0-executable.jar" ]]; then
        echo "pruebas-api-mediplus-1.0.0-executable.jar"
        return 0
    fi
    
    if [[ -f "pruebas-api-mediplus-1.0.0.jar" ]]; then
        echo "pruebas-api-mediplus-1.0.0.jar"
        return 0
    fi
    
    # Buscar en target/
    if [[ -f "target/pruebas-api-mediplus-1.0.0-executable.jar" ]]; then
        echo "target/pruebas-api-mediplus-1.0.0-executable.jar"
        return 0
    fi
    
    if [[ -f "target/pruebas-api-mediplus-1.0.0.jar" ]]; then
        echo "target/pruebas-api-mediplus-1.0.0.jar"
        return 0
    fi
    
    # Buscar cualquier JAR con "mediplus" en el nombre
    jar_encontrado=$(find . -maxdepth 2 -name "*mediplus*.jar" -type f | head -1)
    if [[ -n "$jar_encontrado" ]]; then
        echo "$jar_encontrado"
        return 0
    fi
    
    return 1
}

# Configuración por defecto
DIRECTORIO_RESULTADOS="resultados"
DIRECTORIO_REPORTES="reportes"
JAR_FILE=""

# Detectar JAR automáticamente si no se especifica
JAR_DETECTADO=$(detectar_jar)
if [[ $? -eq 0 ]]; then
    JAR_FILE="$JAR_DETECTADO"
else
    JAR_FILE="target/analisis-metricas-mediplus.jar"  # Fallback
fi

# ===================================================================
# FUNCIONES AUXILIARES
# ===================================================================

# Función de ayuda mejorada
mostrar_ayuda() {
    echo "🚀 Script de Análisis de Métricas JTL - MediPlus"
    echo "================================================"
    echo ""
    echo "Uso: $0 [OPCIONES]"
    echo ""
    echo "Opciones:"
    echo "  -r, --resultados DIR    Directorio con archivos JTL (default: resultados)"
    echo "  -o, --output DIR        Directorio de salida (default: reportes)"
    echo "  -j, --jar FILE          Archivo JAR a ejecutar (auto-detectado)"
    echo "  -h, --help              Mostrar esta ayuda"
    echo "  -v, --verbose           Modo verbose con información detallada"
    echo "  -d, --debug             Modo debug para troubleshooting"
    echo ""
    echo "Ejemplos:"
    echo "  $0                                           # Usar configuración por defecto"
    echo "  $0 -r mis-resultados -o mis-reportes        # Directorios personalizados"
    echo "  $0 --resultados /tmp/jtl --output /tmp/out  # Rutas absolutas"
    echo "  $0 -v                                       # Modo verbose"
    echo "  $0 -j ./mi-jar-custom.jar                   # JAR específico"
    echo ""
    echo "JARs detectados:"
    listar_jars_disponibles
}

# Función para listar JARs disponibles
listar_jars_disponibles() {
    echo "  📦 JARs encontrados en el sistema:"
    
    # Buscar en directorio actual
    for jar in *.jar; do
        if [[ -f "$jar" ]]; then
            echo "    ✅ ./$jar ($(du -h "$jar" | cut -f1))"
        fi
    done
    
    # Buscar en target/
    if [[ -d "target" ]]; then
        for jar in target/*.jar; do
            if [[ -f "$jar" ]]; then
                echo "    ✅ $jar ($(du -h "$jar" | cut -f1))"
            fi
        done
    fi
    
    # Si no se encontró ninguno
    if ! ls *.jar target/*.jar 2>/dev/null | grep -q .; then
        echo "    ⚠️ No se encontraron archivos JAR"
        echo "    💡 Ejecuta: mvn clean package"
    fi
}

# Función para validar entorno
validar_entorno() {
    echo "🔍 Validando entorno de ejecución..."
    
    # Verificar Java
    if ! command -v java &> /dev/null; then
        echo "❌ Error: Java no está instalado o no está en el PATH"
        echo "💡 Instala Java 21 o superior"
        exit 1
    fi
    
    local java_version=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | sed '/^1\./s///' | cut -d'.' -f1)
    if [[ $java_version -lt 21 ]]; then
        echo "⚠️ Advertencia: Se recomienda Java 21 o superior (actual: $java_version)"
    else
        echo "✅ Java $java_version detectado"
    fi
    
    # Verificar permisos de escritura
    if [[ ! -w "." ]]; then
        echo "❌ Error: No hay permisos de escritura en el directorio actual"
        exit 1
    fi
    
    echo "✅ Entorno validado correctamente"
}

# Función para crear datos de prueba si no existen
crear_datos_prueba() {
    if [[ $jtl_count -eq 0 ]]; then
        echo "🧪 No se encontraron archivos JTL. ¿Deseas crear datos de prueba? (y/N)"
        read -r respuesta
        
        if [[ "$respuesta" =~ ^[Yy]$ ]]; then
            echo "📝 Creando datos de prueba..."
            mkdir -p "$DIRECTORIO_RESULTADOS"
            
            # Crear archivo JTL de ejemplo
            cat > "$DIRECTORIO_RESULTADOS/ejemplo_10u.jtl" << 'EOF'
timeStamp,elapsed,label,responseCode,responseMessage,threadName,dataType,success,failureMessage,bytes,sentBytes,grpThreads,allThreads,URL,Filename,latency,encoding,SampleCount,ErrorCount,hostname,idleTime
1703001000000,245,GET_Pacientes,200,OK,Thread Group 1-1,,true,,1024,256,10,10,http://api.mediplus.com/pacientes,,50,UTF-8,1,0,localhost,0
1703001001000,380,POST_Pacientes,201,Created,Thread Group 1-2,,true,,2048,512,10,10,http://api.mediplus.com/pacientes,,75,UTF-8,1,0,localhost,0
1703001002000,315,GET_Pacientes,200,OK,Thread Group 1-3,,true,,1536,256,10,10,http://api.mediplus.com/pacientes,,60,UTF-8,1,0,localhost,0
EOF
            
            echo "✅ Archivo de prueba creado: $DIRECTORIO_RESULTADOS/ejemplo_10u.jtl"
            jtl_count=1
        fi
    fi
}

# Variables para opciones
VERBOSE=false
DEBUG=false

# ===================================================================
# PROCESAMIENTO DE ARGUMENTOS
# ===================================================================

while [[ $# -gt 0 ]]; do
    case $1 in
        -r|--resultados)
            DIRECTORIO_RESULTADOS="$2"
            shift 2
            ;;
        -o|--output)
            DIRECTORIO_REPORTES="$2"
            shift 2
            ;;
        -j|--jar)
            JAR_FILE="$2"
            shift 2
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        -d|--debug)
            DEBUG=true
            VERBOSE=true
            shift
            ;;
        -h|--help)
            mostrar_ayuda
            exit 0
            ;;
        *)
            echo "❌ Opción desconocida: $1"
            echo ""
            mostrar_ayuda
            exit 1
            ;;
    esac
done

# ===================================================================
# EJECUCIÓN PRINCIPAL
# ===================================================================

echo "🚀 Ejecutando Análisis de Métricas MediPlus"
echo "==========================================="
echo "📂 Directorio de resultados: $DIRECTORIO_RESULTADOS"
echo "📂 Directorio de reportes: $DIRECTORIO_REPORTES"
echo "📦 JAR: $JAR_FILE"
echo ""

# Validar entorno si está en modo verbose
if [[ "$VERBOSE" == true ]]; then
    validar_entorno
    echo ""
fi

# Verificar que existe el JAR
if [[ ! -f "$JAR_FILE" ]]; then
    echo "❌ Error: No se encuentra el archivo JAR: $JAR_FILE"
    echo ""
    echo "📦 JARs disponibles:"
    listar_jars_disponibles
    echo ""
    echo "💡 Opciones:"
    echo "   1. Ejecuta: mvn clean package"
    echo "   2. Especifica un JAR existente con: $0 -j ruta/al/archivo.jar"
    echo "   3. Usa un JAR del directorio actual: $0 -j ./nombre-archivo.jar"
    exit 1
fi

# Verificar que existe el directorio de resultados
if [[ ! -d "$DIRECTORIO_RESULTADOS" ]]; then
    echo "❌ Error: No se encuentra el directorio de resultados: $DIRECTORIO_RESULTADOS"
    echo "💡 Crea el directorio o especifica uno existente con: $0 -r directorio-existente"
    exit 1
fi

# Crear directorio de reportes si no existe
mkdir -p "$DIRECTORIO_REPORTES"

# Verificar archivos JTL
jtl_count=$(find "$DIRECTORIO_RESULTADOS" -name "*.jtl" 2>/dev/null | wc -l)
if [[ $jtl_count -eq 0 ]]; then
    echo "⚠️ Advertencia: No se encontraron archivos .jtl en $DIRECTORIO_RESULTADOS"
    echo "💡 Asegúrate de haber ejecutado las pruebas JMeter primero"
    echo ""
    
    # Ofrecer crear datos de prueba
    crear_datos_prueba
fi

echo "📊 Archivos JTL encontrados: $jtl_count"
echo ""

# Mostrar información detallada en modo verbose
if [[ "$VERBOSE" == true ]]; then
    echo "📋 Información detallada:"
    echo "   📦 JAR size: $(du -h "$JAR_FILE" | cut -f1)"
    echo "   📁 Espacio disponible: $(df -h . | tail -1 | awk '{print $4}')"
    echo "   🕒 Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
    echo ""
    
    if [[ $jtl_count -gt 0 ]]; then
        echo "   📄 Archivos JTL encontrados:"
        find "$DIRECTORIO_RESULTADOS" -name "*.jtl" | while read -r file; do
            echo "      ✓ $file ($(du -h "$file" | cut -f1))"
        done
        echo ""
    fi
fi

# Preparar comando de ejecución
JAVA_OPTS=""
if [[ "$DEBUG" == true ]]; then
    JAVA_OPTS="-Xms512m -Xmx2g -XX:+PrintGCDetails -Ddebug=true"
    echo "🔧 Modo DEBUG activado"
    echo "   JAVA_OPTS: $JAVA_OPTS"
    echo ""
fi

# Ejecutar análisis
echo "🔄 Iniciando análisis..."
echo "----------------------------------------"

# Comando base
CMD="java $JAVA_OPTS -jar \"$JAR_FILE\""

# Agregar propiedades del sistema
CMD="$CMD -Ddirectorio.resultados=\"$DIRECTORIO_RESULTADOS\""
CMD="$CMD -Ddirectorio.reportes=\"$DIRECTORIO_REPORTES\""
CMD="$CMD -Dfile.encoding=UTF-8"

# Mostrar comando en modo debug
if [[ "$DEBUG" == true ]]; then
    echo "🔧 Comando a ejecutar:"
    echo "   $CMD"
    echo ""
fi

# Ejecutar con manejo de errores
if eval "$CMD"; then
    echo "----------------------------------------"
    echo ""
    echo "✅ Análisis completado exitosamente!"
    echo "📋 Revisa los reportes en: $DIRECTORIO_REPORTES"
    
    # Mostrar archivos generados
    if [[ -d "$DIRECTORIO_REPORTES" ]]; then
        echo ""
        echo "📄 Archivos generados:"
        find "$DIRECTORIO_REPORTES" -type f | while read -r file; do
            echo "   📝 $file ($(du -h "$file" | cut -f1))"
        done
    fi
    
    # Información adicional en modo verbose
    if [[ "$VERBOSE" == true ]]; then
        echo ""
        echo "🔗 Para abrir el reporte principal:"
        if [[ -f "$DIRECTORIO_REPORTES/reporte_completo.html" ]]; then
            echo "   🌐 open $DIRECTORIO_REPORTES/reporte_completo.html"
        else
            echo "   📂 ls $DIRECTORIO_REPORTES"
        fi
    fi
    
else
    echo "----------------------------------------"
    echo ""
    echo "❌ Error durante la ejecución del análisis"
    echo ""
    echo "🔧 Troubleshooting:"
    echo "   1. Verifica que el JAR sea ejecutable: java -jar \"$JAR_FILE\" --help"
    echo "   2. Revisa los logs de error arriba"
    echo "   3. Ejecuta en modo debug: $0 -d"
    echo "   4. Verifica que los archivos JTL sean válidos"
    exit 1
fi

echo ""
echo "🎉 ¡Script completado con éxito!"