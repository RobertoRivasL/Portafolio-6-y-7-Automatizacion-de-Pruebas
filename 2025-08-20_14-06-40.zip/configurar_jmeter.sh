#!/bin/bash

# Configurador JMeter para Linux - Framework API MediPlus
# Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez

# Configuración de colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Función para mostrar banner
show_banner() {
    echo -e "\n${CYAN}================================================================================${NC}"
    echo -e "${WHITE}            🔧 CONFIGURADOR JMETER - FRAMEWORK API MEDIPLUS${NC}"
    echo -e "${CYAN}================================================================================${NC}"
    echo -e "${WHITE}📊 Configuración automática de JMeter para pruebas de rendimiento${NC}"
    echo -e "${WHITE}👥 Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez${NC}"
    echo -e "${CYAN}================================================================================${NC}"
}

# Función para imprimir mensajes con formato
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_step() {
    echo -e "${PURPLE}🔸 $1${NC}"
}

# Función para detectar JMeter
detect_jmeter() {
    echo -e "\n${YELLOW}🔍 Detectando instalación de JMeter...${NC}"
    
    # Verificar JMETER_HOME
    if [ -n "$JMETER_HOME" ]; then
        if [ -f "$JMETER_HOME/bin/jmeter" ]; then
            print_success "JMeter encontrado via JMETER_HOME: $JMETER_HOME"
            export JMETER_PATH="$JMETER_HOME/bin/jmeter"
            return 0
        else
            print_warning "JMETER_HOME definido pero ejecutable no encontrado: $JMETER_HOME/bin/jmeter"
        fi
    fi
    
    # Verificar PATH
    if command -v jmeter &> /dev/null; then
        JMETER_DETECTED=$(which jmeter)
        print_success "JMeter encontrado en PATH: $JMETER_DETECTED"
        export JMETER_PATH="jmeter"
        return 0
    fi
    
    # Verificar ubicaciones comunes
    local common_paths=(
        "/opt/apache-jmeter-5.6.3/bin/jmeter"
        "/usr/local/apache-jmeter-5.6.3/bin/jmeter"
        "$HOME/apache-jmeter-5.6.3/bin/jmeter"
        "/usr/share/jmeter/bin/jmeter"
    )
    
    for path in "${common_paths[@]}"; do
        if [ -f "$path" ]; then
            print_success "JMeter encontrado en: $path"
            export JMETER_PATH="$path"
            export JMETER_HOME=$(dirname $(dirname "$path"))
            return 0
        fi
    done
    
    print_error "JMeter no encontrado en el sistema"
    print_info "Instala JMeter desde: https://jmeter.apache.org/download_jmeter.cgi"
    return 1
}

# Función para crear directorios
create_directories() {
    print_step "Creando estructura de directorios..."
    
    local dirs=("jmeter" "resultados" "temp")
    
    for dir in "${dirs[@]}"; do
        if mkdir -p "$dir" 2>/dev/null; then
            print_success "Directorio creado: $dir/"
        else
            print_warning "No se pudo crear directorio: $dir/"
        fi
    done
}

# Función para crear script JMeter de verificación
create_verification_script() {
    print_step "Creando script de verificación JMeter..."
    
    cat > jmeter/verificacion.jmx << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.6.3">
  <hashTree>
    <TestPlan guiclass="TestPlanGui" testclass="TestPlan" testname="Verificación JMeter Linux" enabled="true">
      <stringProp name="TestPlan.comments">Script de verificación para instalación JMeter en Linux</stringProp>
      <boolProp name="TestPlan.functional_mode">false</boolProp>
      <boolProp name="TestPlan.tearDown_on_shutdown">true</boolProp>
      <boolProp name="TestPlan.serialize_threadgroups">false</boolProp>
      <elementProp name="TestPlan.arguments" elementType="Arguments" guiclass="ArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
        <collectionProp name="Arguments.arguments"/>
      </elementProp>
    </TestPlan>
    <hashTree>
      <ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="Grupo Verificación" enabled="true">
        <stringProp name="ThreadGroup.on_sample_error">continue</stringProp>
        <elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControllerGui" testclass="LoopController" testname="Loop Controller" enabled="true">
          <boolProp name="LoopController.continue_forever">false</boolProp>
          <intProp name="LoopController.loops">3</intProp>
        </elementProp>
        <stringProp name="ThreadGroup.num_threads">2</stringProp>
        <stringProp name="ThreadGroup.ramp_time">2</stringProp>
        <boolProp name="ThreadGroup.scheduler">false</boolProp>
        <stringProp name="ThreadGroup.duration"></stringProp>
        <stringProp name="ThreadGroup.delay"></stringProp>
      </ThreadGroup>
      <hashTree>
        <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="GET Verificación" enabled="true">
          <elementProp name="HTTPsampler.Arguments" elementType="Arguments" guiclass="HTTPArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
            <collectionProp name="Arguments.arguments"/>
          </elementProp>
          <stringProp name="HTTPSampler.domain">httpbin.org</stringProp>
          <stringProp name="HTTPSampler.port"></stringProp>
          <stringProp name="HTTPSampler.protocol">https</stringProp>
          <stringProp name="HTTPSampler.contentEncoding"></stringProp>
          <stringProp name="HTTPSampler.path">/get</stringProp>
          <stringProp name="HTTPSampler.method">GET</stringProp>
          <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
          <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
          <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
          <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
          <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
          <stringProp name="HTTPSampler.connect_timeout">5000</stringProp>
          <stringProp name="HTTPSampler.response_timeout">10000</stringProp>
        </HTTPSamplerProxy>
        <hashTree/>
      </hashTree>
    </hashTree>
  </hashTree>
</jmeterTestPlan>
EOF

    if [ -f "jmeter/verificacion.jmx" ]; then
        print_success "Script de verificación creado: jmeter/verificacion.jmx"
    else
        print_error "Error creando script de verificación"
        return 1
    fi
}

# Función para ejecutar configurador Java
run_java_configurator() {
    print_step "Ejecutando configurador Java..."
    
    if command -v mvn &> /dev/null; then
        if mvn exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.jmeter.ConfiguradorJMeter" -q; then
            print_success "Configurador Java ejecutado correctamente"
        else
            print_warning "Error en configurador Java, continuando..."
        fi
    else
        print_warning "Maven no encontrado, omitiendo configurador Java"
    fi
}

# Función para ejecutar prueba rápida
run_quick_test() {
    if [ -z "$JMETER_PATH" ]; then
        print_warning "JMeter no disponible, omitiendo prueba rápida"
        return 1
    fi
    
    print_step "Ejecutando prueba rápida de JMeter..."
    
    local result_file="resultados/test_verificacion_$(date +%Y%m%d_%H%M%S).jtl"
    
    echo -e "${BLUE}🚀 Comando: $JMETER_PATH -n -t jmeter/verificacion.jmx -l $result_file${NC}"
    
    if "$JMETER_PATH" -n -t jmeter/verificacion.jmx -l "$result_file" -j temp/jmeter_test.log > temp/jmeter_output.txt 2>&1; then
        print_success "Prueba rápida completada exitosamente"
        
        if [ -f "$result_file" ]; then
            local line_count=$(wc -l < "$result_file" 2>/dev/null || echo "0")
            print_info "Registros generados: $line_count"
            print_info "Archivo de resultados: $result_file"
        fi
        
        return 0
    else
        print_error "Prueba rápida falló"
        
        if [ -f "temp/jmeter_output.txt" ]; then
            echo -e "${YELLOW}📄 Últimas líneas del log:${NC}"
            tail -n 5 temp/jmeter_output.txt
        fi
        
        return 1
    fi
}

# Función para mostrar resumen
show_summary() {
    echo -e "\n${CYAN}================================================================================${NC}"
    echo -e "${WHITE}🎉 CONFIGURACIÓN JMETER COMPLETADA${NC}"
    echo -e "${CYAN}================================================================================${NC}"
    
    echo -e "\n${WHITE}✅ Estado de la configuración:${NC}"
    
    if [ -n "$JMETER_HOME" ]; then
        echo -e "  📁 JMETER_HOME: $JMETER_HOME"
    fi
    
    if [ -n "$JMETER_PATH" ]; then
        echo -e "  🔧 Ejecutable: $JMETER_PATH"
        
        # Mostrar versión si es posible
        if command -v "$JMETER_PATH" &> /dev/null; then
            local version_info=$("$JMETER_PATH" --version 2>/dev/null | head -n 1 || echo "Versión no disponible")
            echo -e "  📋 Versión: $version_info"
        fi
    else
        echo -e "  ❌ JMeter: No configurado"
    fi
    
    echo -e "  📂 Scripts: jmeter/*.jmx"
    echo -e "  📊 Resultados: resultados/"
    
    echo -e "\n${WHITE}💡 PRÓXIMOS PASOS:${NC}"
    echo -e "  1. Ejecutar: ./ejecutar_evidencias_completas.sh"
    echo -e "  2. O individual: mvn exec:java -Dexec.mainClass=\"com.mediplus.pruebas.analisis.jmeter.EjecutorJMeterRobusto\""
    echo -e "  3. Revisar resultados en: evidencias/"
    
    if [ -n "$JMETER_PATH" ]; then
        echo -e "\n${WHITE}🔗 COMANDOS ÚTILES:${NC}"
        echo -e "  - Ver versión: $JMETER_PATH --version"
        echo -e "  - GUI JMeter: $JMETER_PATH"
        echo -e "  - Ejecutar script: $JMETER_PATH -n -t jmeter/verificacion.jmx -l resultados/test.jtl"
    fi
    
    echo -e "\n${GREEN}🎯 ¡Configuración de JMeter lista para usar!${NC}"
    echo -e "${CYAN}================================================================================${NC}"
}

# Función principal
main() {
    show_banner
    
    # Verificar que estamos en el directorio correcto
    if [ ! -f "pom.xml" ]; then
        print_error "No se encuentra pom.xml. Ejecuta desde el directorio raíz del proyecto."
        exit 1
    fi
    
    # Crear directorios necesarios
    create_directories
    
    # Detectar JMeter
    if detect_jmeter; then
        # Crear script de verificación
        create_verification_script
        
        # Ejecutar configurador Java
        run_java_configurator
        
        # Ejecutar prueba rápida
        run_quick_test
    else
        print_warning "JMeter no detectado. El framework usará datos simulados."
        print_info "Para instalar JMeter en Ubuntu/Debian:"
        print_info "  sudo apt update && sudo apt install jmeter"
        print_info "O descargar desde: https://jmeter.apache.org/download_jmeter.cgi"
    fi
    
    # Mostrar resumen
    show_summary
}

# Ejecutar función principal
main "$@"