# Crear script de corrección simple
cat > corregir-script.sh << 'EOF'
#!/bin/bash

echo "🔧 Corrigiendo script ejecutar-evidencias.sh..."

# Backup del script original
cp ejecutar-evidencias.sh ejecutar-evidencias.sh.backup

# Corregir las líneas problemáticas
sed -i 's/sed -i.*statusCode(200).*/# Corrección automática deshabilitada - ya corregido manualmente/g' ejecutar-evidencias.sh
sed -i 's/sed -i.*statusCode(400).*/# Corrección automática deshabilitada - ya corregido manualmente/g' ejecutar-evidencias.sh

echo "✅ Script corregido. Las correcciones automáticas están deshabilitadas."
echo "ℹ️  Los tests ya están corregidos manualmente, así que no son necesarias."
EOF

chmod +x corregir-script.sh
./corregir-script.sh