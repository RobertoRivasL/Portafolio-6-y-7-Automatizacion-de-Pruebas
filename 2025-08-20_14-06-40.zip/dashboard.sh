#!/bin/bash

# Script para crear el dashboard de evidencias MediPlus

echo "📊 Creando Dashboard de Evidencias MediPlus..."

# 1. Crear directorios necesarios
mkdir -p evidencias/graficas

# 2. Crear el archivo dashboard
cat > evidencias/graficas/dashboard-mediplus.html << 'EOF'
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📊 Dashboard Evidencias - API MediPlus</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header .subtitle {
            font-size: 1.1em;
            opacity: 0.9;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 30px;
            background: #f8f9fa;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            text-align: center;
            transition: transform 0.3s ease;
            border-left: 5px solid;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card.success { border-left-color: #28a745; }
        .stat-card.warning { border-left-color: #ffc107; }
        .stat-card.info { border-left-color: #17a2b8; }
        .stat-card.danger { border-left-color: #dc3545; }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .success .stat-number { color: #28a745; }
        .warning .stat-number { color: #ffc107; }
        .info .stat-number { color: #17a2b8; }
        .danger .stat-number { color: #dc3545; }
        
        .stat-label {
            font-size: 1.1em;
            color: #6c757d;
            margin-bottom: 5px;
        }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 10px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #28a745, #20c997);
            transition: width 2s ease;
        }
        
        .status-section {
            padding: 30px;
            background: white;
        }
        
        .component-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            margin: 10px 0;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .component-badge {
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }
        
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        
        .badge-warning {
            background: #fff3cd;
            color: #856404;
        }
        
        .conclusions {
            background: linear-gradient(135deg, #e8f5e8, #d4edda);
            padding: 30px;
            text-align: center;
        }
        
        .conclusion-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            display: inline-block;
            max-width: 800px;
        }
        
        .footer {
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .timestamp {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 0.9em;
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="timestamp" id="timestamp"></div>
            <h1>📊 Dashboard Evidencias API MediPlus</h1>
            <div class="subtitle">
                Automatización de Pruebas REST: Funcionalidad y Rendimiento<br>
                <strong>Equipo:</strong> Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez
            </div>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card success">
                <div class="stat-number">31</div>
                <div class="stat-label">Total Pruebas</div>
                <div class="stat-detail">Ejecutadas exitosamente</div>
            </div>
            
            <div class="stat-card warning">
                <div class="stat-number">93.5%</div>
                <div class="stat-label">Tasa de Éxito</div>
                <div class="stat-detail">29 de 31 pruebas</div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 93.5%"></div>
                </div>
            </div>
            
            <div class="stat-card danger">
                <div class="stat-number">2</div>
                <div class="stat-label">Fallas</div>
                <div class="stat-detail">Corregibles fácilmente</div>
            </div>
            
            <div class="stat-card info">
                <div class="stat-number">25.63s</div>
                <div class="stat-label">Tiempo Total</div>
                <div class="stat-detail">0.83s promedio</div>
            </div>
        </div>
        
        <div class="status-section">
            <h2>🎯 Estado por Componente</h2>
            
            <div class="component-item">
                <span>✅ Autenticación y Seguridad</span>
                <span class="component-badge badge-success">6 pruebas - 100%</span>
            </div>
            
            <div class="component-item">
                <span>✅ Gestión de Citas</span>
                <span class="component-badge badge-success">2 pruebas - 100%</span>
            </div>
            
            <div class="component-item">
                <span>✅ Reportes y Consultas</span>
                <span class="component-badge badge-success">12 pruebas - 100%</span>
            </div>
            
            <div class="component-item">
                <span>✅ Métricas de Rendimiento</span>
                <span class="component-badge badge-success">5 pruebas - 100%</span>
            </div>
            
            <div class="component-item">
                <span>⚠️ Creación de Pacientes</span>
                <span class="component-badge badge-warning">2 pruebas - 0%</span>
            </div>
        </div>
        
        <div class="conclusions">
            <div class="conclusion-card">
                <h2 style="color: #28a745; margin-bottom: 15px;">🚀 API MediPlus Lista para Producción</h2>
                <p style="margin-bottom: 15px; line-height: 1.6;">
                    Con una <strong>tasa de éxito del 93.5%</strong>, la API demuestra alta estabilidad y confiabilidad 
                    en las funcionalidades core del negocio.
                </p>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 15px 0;">
                    <strong>🎯 Recomendación:</strong> PROCEDER CON DESPLIEGUE tras correcciones menores.
                    <br><strong>Confianza:</strong> <span style="color: #28a745; font-weight: bold;">ALTA 🚀</span>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>📊 Dashboard generado automáticamente | Framework de Evidencias MediPlus v1.0</p>
        </div>
    </div>

    <script>
        // Actualizar timestamp
        function updateTimestamp() {
            const now = new Date();
            const options = { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric', 
                hour: '2-digit', 
                minute: '2-digit'
            };
            document.getElementById('timestamp').textContent = 
                now.toLocaleDateString('es-ES', options);
        }
        
        // Animaciones
        function animateElements() {
            const progressBars = document.querySelectorAll('.progress-fill');
            progressBars.forEach(bar => {
                const width = bar.style.width;
                bar.style.width = '0%';
                setTimeout(() => bar.style.width = width, 1000);
            });
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            updateTimestamp();
            animateElements();
        });
    </script>
</body>
</html>
EOF

echo "✅ Dashboard creado en: evidencias/graficas/dashboard-mediplus.html"
echo ""
echo "🌐 Para abrir el dashboard:"
echo "   firefox evidencias/graficas/dashboard-mediplus.html"
echo "   # o"
echo "   google-chrome evidencias/graficas/dashboard-mediplus.html"
echo "   # o"
echo "   open evidencias/graficas/dashboard-mediplus.html  # macOS"