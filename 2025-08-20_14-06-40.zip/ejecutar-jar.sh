
#!/bin/bash

# Script para ejecutar JARs correctamente
# Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🚀 EJECUTOR DE JARS - MEDIPLUS${NC}"
echo "======================================================================"

# Función para encontrar clases con main
encontrar_clases_main() {
    echo -e "${YELLOW}🔍 Buscando clases con método main...${NC}"
    
    if [ -d "src/main/java" ]; then
        echo "📁 Clases con main encontradas:"
        grep -r "public static void main" src/main/java/ 2>/dev/null | while read line; do
            local file=$(echo "$line" | cut -d: -f1)
            local class_path=$(echo "$file" | sed 's|src/main/java/||' | sed 's|\.java||' | sed 's|/|.|g')
            echo "  ✅ $class_path"
        done
    else
        echo -e "${RED}❌ Directorio src/main/java no encontrado${NC}"
    fi
}

# Función para listar JARs disponibles
listar_jars() {
    echo -e "${YELLOW}📦 JARs disponibles:${NC}"
    
    if [ -d "target" ]; then
        find target -name "*.jar" -type f | while read jar; do
            local size=$(du -h "$jar" | cut -f1)
            echo "  📦 $(basename "$jar") ($size)"
        done
    else
        echo -e "${RED}❌ Directorio target no encontrado${NC}"
    fi
}

# Función para ejecutar clase específica
ejecutar_clase() {
    local clase=$1
    
    echo -e "${BLUE}🎯 Ejecutando clase: $clase${NC}"
    
    if [ -d "target/classes" ]; then
        if java -cp target/classes "$clase"; then
            echo -e "${GREEN}✅ Ejecución exitosa${NC}"
        else
            echo -e "${RED}❌ Error en ejecución${NC}"
        fi
    else
        echo -e "${RED}❌ Clases no compiladas. Ejecuta: mvn compile${NC}"
    fi
}

# Función para ejecutar JAR específico
ejecutar_jar() {
    local jar_file=$1
    
    if [ ! -f "$jar_file" ]; then
        echo -e "${RED}❌ JAR no encontrado: $jar_file${NC}"
        return 1
    fi
    
    echo -e "${BLUE}🎯 Ejecutando JAR: $jar_file${NC}"
    
    if java -jar "$jar_file"; then
        echo -e "${GREEN}✅ JAR ejecutado exitosamente${NC}"
    else
        echo -e "${RED}❌ Error ejecutando JAR${NC}"
        return 1
    fi
}

# Función para compilar y generar JARs
compilar_y_generar() {
    echo -e "${YELLOW}🔨 Compilando y generando JARs...${NC}"
    
    # Limpiar y compilar
    mvn clean compile || {
        echo -e "${RED}❌ Error en compilación${NC}"
        return 1
    }
    
    # Generar JARs
    mvn package -DskipTests || {
        echo -e "${RED}❌ Error generando JARs${NC}"
        return 1
    }
    
    echo -e "${GREEN}✅ JARs generados exitosamente${NC}"
    listar_jars
}

# Función para ejecutar todo automáticamente
ejecutar_automatico() {
    echo -e "${YELLOW}🤖 Ejecución automática...${NC}"
    
    # Prioridad de clases a ejecutar
    local clases=(
        "com.mediplus.pruebas.analisis.test.PruebasBasicas"
        "com.mediplus.pruebas.analisis.ejecutor.EjecutorEvidenciasCompleto"
        "com.mediplus.pruebas.analisis.evidencias.GeneradorGraficas"
        "com.mediplus.pruebas.analisis.evidencias.GeneradorEvidencias"
    )
    
    echo "🎯 Intentando ejecutar clases en orden de prioridad..."
    
    for clase in "${clases[@]}"; do
        echo ""
        echo -e "${BLUE}Probando: $clase${NC}"
        
        if java -cp target/classes "$clase" 2>/dev/null; then
            echo -e "${GREEN}✅ $clase ejecutado exitosamente${NC}"
            return 0
        else
            echo -e "${YELLOW}⚠️  $clase no se pudo ejecutar${NC}"
        fi
    done
    
    echo -e "${RED}❌ Ninguna clase se pudo ejecutar${NC}"
    return 1
}

# Función para mostrar ayuda
mostrar_ayuda() {
    echo "📖 USO DEL EJECUTOR DE JARS:"
    echo ""
    echo "🔸 Encontrar clases con main:"
    echo "   $0 find"
    echo ""
    echo "🔸 Listar JARs disponibles:"
    echo "   $0 list"
    echo ""
    echo "🔸 Ejecutar clase específica:"
    echo "   $0 class com.mediplus.pruebas.analisis.test.PruebasBasicas"
    echo ""
    echo "🔸 Ejecutar JAR específico:"
    echo "   $0 jar target/api-pruebas-automatizadas-pruebas-completo.jar"
    echo ""
    echo "🔸 Compilar y generar JARs:"
    echo "   $0 build"
    echo ""
    echo "🔸 Ejecución automática (prueba todas las clases):"
    echo "   $0 auto"
    echo ""
    echo "🔸 Comandos rápidos comunes:"
    echo "   $0 pruebas    # Ejecutar PruebasBasicas"
    echo "   $0 evidencias # Ejecutar EjecutorEvidencias"
    echo "   $0 graficas   # Ejecutar GeneradorGraficas"
}

# Función principal
main() {
    local comando=${1:-help}
    
    case "$comando" in
        "find"|"buscar")
            encontrar_clases_main
            ;;
        "list"|"listar")
            listar_jars
            ;;
        "class"|"clase")
            if [ -z "$2" ]; then
                echo -e "${RED}❌ Especifica la clase a ejecutar${NC}"
                exit 1
            fi
            ejecutar_clase "$2"
            ;;
        "jar")
            if [ -z "$2" ]; then
                echo -e "${RED}❌ Especifica el JAR a ejecutar${NC}"
                exit 1
            fi
            ejecutar_jar "$2"
            ;;
        "build"|"compilar")
            compilar_y_generar
            ;;
        "auto"|"automatico")
            ejecutar_automatico
            ;;
        "pruebas")
            ejecutar_clase "com.mediplus.pruebas.analisis.test.PruebasBasicas"
            ;;
        "evidencias")
            ejecutar_clase "com.mediplus.pruebas.analisis.ejecutor.EjecutorEvidenciasCompleto"
            ;;
        "graficas")
            ejecutar_clase "com.mediplus.pruebas.analisis.evidencias.GeneradorGraficas"
            ;;
        "help"|"-h"|"--help")
            mostrar_ayuda
            ;;
        *)
            echo -e "${RED}❌ Comando no válido: $comando${NC}"
            mostrar_ayuda
            exit 1
            ;;
    esac
}

main "$@"