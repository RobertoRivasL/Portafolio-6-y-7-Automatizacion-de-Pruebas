#!/bin/bash

# Script de ejecución completa del Framework de Evidencias API MediPlus
# Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez

# ===================== Configuración de colores =====================
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'
PURPLE='\033[0;35m'; CYAN='\033[0;36m'; WHITE='\033[1;37m'; NC='\033[0m'

export JAVA_OPTS="-Xmx2g -XX:+UseG1GC"
export MAVEN_OPTS="-Xmx1g"

print_header(){ echo -e "\n${CYAN}================================================================================${NC}\n${WHITE}$1${NC}\n${CYAN}================================================================================${NC}"; }
print_step(){ echo -e "\n${BLUE}🔸 $1${NC}"; }
print_success(){ echo -e "${GREEN}✅ $1${NC}"; }
print_warning(){ echo -e "${YELLOW}⚠️  $1${NC}"; }
print_error(){ echo -e "${RED}❌ $1${NC}"; }

# ===================== Utilidades =====================
# Normaliza rutas con espacios (siempre comilladas)
q(){ printf '"%s"' "$1"; }

# Detecta JMeter (bat en Windows / sh en Linux/mac)
detect_jmeter(){
  if command -v jmeter &>/dev/null; then
    JMETER_CMD="jmeter"
    return 0
  fi
  # Intenta ubicaciones típicas en Windows
  local CANDIDATES=(
    "/c/Program Files/Apache Software Foundation/apache-jmeter-5.6.3/bin/jmeter.bat"
    "/c/Program Files/apache-jmeter-5.6.3/bin/jmeter.bat"
    "/c/apache-jmeter-5.6.3/bin/jmeter.bat"
  )
  for p in "${CANDIDATES[@]}"; do
    if [ -f "$p" ]; then JMETER_CMD="$p"; return 0; fi
  done
  return 1
}

# Ejecuta un .jmx con JMeter en modo no-GUI, genera .jtl y dashboard HTML
run_jmx(){
  local jmx_file="$1"
  local name="$2"

  mkdir -p "resultados" "reportes"

  local ts; ts=$(date '+%Y-%m-%d_%H-%M-%S')
  local jtl="resultados/${name}_${ts}.jtl"
  local outdir="reportes/${name}_${ts}"

  print_step "Ejecutando escenario: ${name}"
  print_step "JMX: $(q "$jmx_file")"
  print_step "JTL: $(q "$jtl")"
  print_step "Reporte HTML: $(q "$outdir")"

  # IMPORTANTE: TODAS LAS RUTAS VAN ENTRE COMILLAS
  if [[ "$JMETER_CMD" == *".bat" ]]; then
    # Windows (Git Bash): usar cmd /c para correcta expansión y retorno de código
    cmd.exe /c "\"$(cygpath -w "$JMETER_CMD")\" -n -t \"$(cygpath -w "$jmx_file")\" -l \"$(cygpath -w "$jtl")\" -e -o \"$(cygpath -w "$outdir")\""
  else
    "$JMETER_CMD" -n -t "$jmx_file" -l "$jtl" -e -o "$outdir"
  fi

  local rc=$?
  if [ $rc -ne 0 ]; then
    print_error "JMeter falló (rc=$rc) en escenario ${name}"
    return $rc
  fi
  print_success "Escenario ${name} completado. Reporte en: $(q "$outdir")"
}

# ===================== Banner =====================
clear
print_header "🚀 FRAMEWORK DE EVIDENCIAS API MEDIPLUS - EJECUCIÓN COMPLETA"
echo -e "${WHITE}📊 Automatización de Pruebas REST - Funcionalidad y Rendimiento${NC}"
echo -e "${WHITE}👥 Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez${NC}"
echo -e "${WHITE}🕒 Iniciando: $(date '+%d/%m/%Y %H:%M:%S')${NC}"

# ===================== PASO 1: Verificar entorno =====================
print_header "🔍 PASO 1: Verificando entorno de desarrollo..."

print_step "Verificando Java..."
if command -v java &>/dev/null; then
  java_version=$(java --version 2>&1 | head -n1)
  print_success "Java encontrado: $java_version"
  if ! java --version 2>&1 | grep -q "21"; then
    print_warning "Se recomienda Java 21 para compatibilidad completa"
  fi
else
  print_error "Java no encontrado. Instala Java 21."
  exit 1
fi

print_step "Verificando Maven..."
if command -v mvn &>/dev/null; then
  print_success "Maven encontrado: $(mvn -v | head -n1)"
else
  print_error "Maven no encontrado."
  exit 1
fi

print_step "Verificando JMeter..."
if detect_jmeter; then
  print_success "JMeter encontrado: $JMETER_CMD"
else
  print_error "JMeter no encontrado. Instala JMeter 5.6.3 y vuelve a intentar."
  exit 1
fi

print_step "Verificando estructura del proyecto..."
[ -f "pom.xml" ] && print_success "pom.xml OK" || { print_error "pom.xml no encontrado"; exit 1; }

# ===================== PASO 2: Compilar =====================
print_header "🏗️  PASO 2: Compilando proyecto..."
print_step "mvn clean compile"
mvn -q clean compile || { print_error "Error en compilación"; exit 1; }
print_success "Proyecto compilado"

# ===================== PASO 3: Pruebas básicas (Java) =====================
print_header "🧪 PASO 3: Ejecutando pruebas básicas..."
mvn -q exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.test.PruebasBasicas" \
  && print_success "Pruebas básicas completadas" \
  || print_warning "Pruebas básicas con errores (continuando)"

# ===================== PASO 4: Pruebas de rendimiento con JMeter =====================
print_header "📊 PASO 4: Ejecutando pruebas JMeter (no-GUI, con dashboard)"
# IMPORTANTE: ejecutamos JMeter DIRECTAMENTE para evitar problemas de quoting dentro de Java
# Asegura que los .jmx existan en ./jmeter/
declare -A PLANES=(
  ["GET_MASIVO"]="jmeter/get_masivo.jmx"
  ["POST_MASIVO"]="jmeter/post_masivo.jmx"
  ["MIXTO"]="jmeter/mixto.jmx"
)

for nombre in "${!PLANES[@]}"; do
  jmx="${PLANES[$nombre]}"
  if [ -f "$jmx" ]; then
    run_jmx "$jmx" "$nombre" || { print_error "Abortando por fallo en $nombre"; exit 1; }
  else
    print_warning "No encontrado: $(q "$jmx") — se omite $nombre"
  fi
done

# ===================== PASO 5..8 (igual que antes) =====================
print_header "📈 PASO 5: Generando análisis de métricas..."
mvn -q exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.AnalizadorMetricas" \
  && print_success "Análisis de métricas OK" || print_warning "Análisis con errores"

print_header "🎨 PASO 6: Generando gráficas y evidencias..."
mvn -q exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.evidencias.GeneradorEvidencias" || true
mvn -q exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.evidencias.GeneradorGraficas" || true
print_success "Paso 6 completado (con tolerancia a fallos)"

print_header "🏁 PASO 7: Proceso completo integrado..."
mvn -q exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.ejecutor.EjecutorEvidenciasCompleto" || true

print_header "📋 PASO 8: Generando reporte Surefire..."
mvn -q exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.evidencias.AnalizadorResultadosSurefire" || true

# ===================== Resumen =====================
print_header "🎉 PROCESO COMPLETADO - RESUMEN FINAL"
print_success "Framework de evidencias ejecutado exitosamente"

echo -e "\n${WHITE}📁 ARCHIVOS GENERADOS:${NC}"
echo -e "  📊 reportes/* (Dashboards HTML por escenario)"
echo -e "  🧪 resultados/*.jtl (Resultados crudos)"
echo -e "  📄 evidencias/* (informes complementarios)"

# Intento apertura de un dashboard reciente
LAST_DASH=$(ls -1dt reportes/* 2>/dev/null | head -n1)
if [ -n "$LAST_DASH" ] && [ -f "$LAST_DASH/index.html" ]; then
  print_step "Último dashboard: $(q "$LAST_DASH/index.html")"
  if command -v xdg-open &>/dev/null; then xdg-open "$LAST_DASH/index.html" >/dev/null 2>&1 & fi
  if command -v open &>/dev/null; then open "$LAST_DASH/index.html" >/dev/null 2>&1 & fi
fi

print_header "📂 ESTRUCTURA FINAL GENERADA"
if command -v tree &>/dev/null; then
  tree -L 2 resultados reportes evidencias 2>/dev/null || true
else
  find resultados reportes evidencias -maxdepth 2 -type f 2>/dev/null | sort
fi

print_header "🎯 ¡FRAMEWORK DE EVIDENCIAS API MEDIPLUS COMPLETADO EXITOSAMENTE!"
