#!/bin/bash

# Script de ejecución completa del Framework de Evidencias API MediPlus
# Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez

# Configuración de colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Configuración del entorno
export JAVA_OPTS="-Xmx2g -XX:+UseG1GC"
export MAVEN_OPTS="-Xmx1g"

# Función para mostrar mensajes con formato
print_header() {
    echo -e "\n${CYAN}================================================================================${NC}"
    echo -e "${WHITE}$1${NC}"
    echo -e "${CYAN}================================================================================${NC}"
}

print_step() {
    echo -e "\n${BLUE}🔸 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Banner principal
clear
print_header "🚀 FRAMEWORK DE EVIDENCIAS API MEDIPLUS - EJECUCIÓN COMPLETA"
echo -e "${WHITE}📊 Automatización de Pruebas REST - Funcionalidad y Rendimiento${NC}"
echo -e "${WHITE}👥 Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez${NC}"
echo -e "${WHITE}🕒 Iniciando: $(date '+%d/%m/%Y %H:%M:%S')${NC}"

# Paso 1: Verificar entorno
print_header "🔍 PASO 1: Verificando entorno de desarrollo..."

# Verificar Java
print_step "Verificando Java..."
if command -v java &> /dev/null; then
    java_version=$(java --version 2>&1 | head -n 1)
    print_success "Java encontrado: $java_version"
    
    if java --version 2>&1 | grep -q "21"; then
        print_success "Java 21 detectado - Versión correcta"
    else
        print_warning "Se recomienda Java 21 para compatibilidad completa"
    fi
else
    print_error "Java no encontrado. Instala Java 21 antes de continuar."
    exit 1
fi

# Verificar Maven
print_step "Verificando Maven..."
if command -v mvn &> /dev/null; then
    maven_version=$(mvn --version 2>&1 | head -n 1)
    print_success "Maven encontrado: $maven_version"
else
    print_error "Maven no encontrado. Instala Maven antes de continuar."
    echo "💡 Descarga Maven desde: https://maven.apache.org/download.cgi"
    exit 1
fi

# Verificar JMeter (opcional)
print_step "Verificando JMeter..."
if command -v jmeter &> /dev/null; then
    jmeter_version=$(jmeter --version 2>&1 | head -n 1)
    print_success "JMeter encontrado: $jmeter_version"
else
    print_warning "JMeter no encontrado - Se generarán datos simulados"
fi

# Verificar estructura del proyecto
print_step "Verificando estructura del proyecto..."
if [ -f "pom.xml" ]; then
    print_success "Archivo pom.xml encontrado"
else
    print_error "Archivo pom.xml no encontrado. Ejecuta desde el directorio raíz del proyecto."
    exit 1
fi

if [ -d "src" ]; then
    print_success "Directorio src encontrado"
else
    print_warning "Directorio src no encontrado"
fi

# Paso 2: Compilar proyecto
print_header "🏗️  PASO 2: Compilando proyecto..."

print_step "Ejecutando maven clean compile..."
if mvn clean compile; then
    print_success "Proyecto compilado exitosamente"
else
    print_error "Error en compilación. Revisa las dependencias en pom.xml"
    exit 1
fi

# Paso 3: Ejecutar pruebas básicas
print_header "🧪 PASO 3: Ejecutando pruebas básicas..."

print_step "Ejecutando PruebasBasicas..."
if mvn exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.test.PruebasBasicas"; then
    print_success "Pruebas básicas completadas"
else
    print_warning "Error en pruebas básicas, continuando..."
fi

# Paso 4: Ejecutar JMeter robusto
print_header "📊 PASO 4: Ejecutando pruebas JMeter robustas..."

print_step "Ejecutando EjecutorJMeterRobusto..."
if mvn exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.jmeter.EjecutorJMeterRobusto"; then
    print_success "Pruebas JMeter completadas"
else
    print_warning "Error en JMeter, continuando con datos simulados..."
fi

# Paso 5: Análisis de métricas
print_header "📈 PASO 5: Generando análisis de métricas..."

print_step "Ejecutando AnalizadorMetricas..."
if mvn exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.AnalizadorMetricas"; then
    print_success "Análisis de métricas completado"
else
    print_warning "Error en análisis de métricas, continuando..."
fi

# Paso 6: Generar gráficas y evidencias
print_header "🎨 PASO 6: Generando gráficas y evidencias..."

print_step "Ejecutando GeneradorEvidencias..."
if mvn exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.evidencias.GeneradorEvidencias"; then
    print_success "Evidencias generadas"
else
    print_warning "Error en generador de evidencias, continuando..."
fi

print_step "Ejecutando GeneradorGraficas..."
if mvn exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.evidencias.GeneradorGraficas"; then
    print_success "Gráficas generadas"
else
    print_warning "Error en generador de gráficas, continuando..."
fi

# Paso 7: Proceso completo integrado
print_header "🏁 PASO 7: Ejecutando proceso completo integrado..."

print_step "Ejecutando EjecutorEvidenciasCompleto..."
if mvn exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.ejecutor.EjecutorEvidenciasCompleto"; then
    print_success "Proceso completo ejecutado"
else
    print_warning "Error en ejecutor completo, revisa los logs..."
fi

# Paso 8: Reporte Surefire
print_header "📋 PASO 8: Generando reporte Surefire..."

print_step "Ejecutando AnalizadorResultadosSurefire..."
if mvn exec:java -Dexec.mainClass="com.mediplus.pruebas.analisis.evidencias.AnalizadorResultadosSurefire"; then
    print_success "Reporte Surefire generado"
else
    print_warning "Error en analizador Surefire, continuando..."
fi

# Resumen final
print_header "🎉 PROCESO COMPLETADO - RESUMEN FINAL"

print_success "Framework de evidencias ejecutado exitosamente"

echo ""
echo -e "${WHITE}📁 ARCHIVOS GENERADOS:${NC}"
echo -e "  📊 evidencias/graficas/          - Gráficas ASCII y HTML"
echo -e "  🧪 evidencias/ejecuciones/       - Logs de pruebas"
echo -e "  📋 evidencias/reportes/          - Reportes técnicos"
echo -e "  📄 evidencias/REPORTE-EJECUTIVO-*.md  - Reporte principal"
echo -e "  🔗 evidencias/INDICE-EVIDENCIAS.md    - Índice completo"

echo ""
echo -e "${WHITE}🌐 PARA REVISAR:${NC}"
echo -e "  1. Abrir: evidencias/graficas/reporte-metricas.html"
echo -e "  2. Leer:  evidencias/REPORTE-EJECUTIVO-*.md"
echo -e "  3. Ver:   evidencias/INDICE-EVIDENCIAS.md"

echo ""
echo -e "${WHITE}📈 RESULTADOS JMETER:${NC}"
if ls resultados/*.jtl 1> /dev/null 2>&1; then
    print_success "Archivos JTL generados en: resultados/"
    echo -e "  📊 Escenarios: GET Masivo, POST Masivo, Mixto"
    echo -e "  📋 Total archivos: $(ls resultados/*.jtl 2>/dev/null | wc -l)"
else
    print_warning "No se encontraron archivos JTL - Datos simulados utilizados"
fi

echo ""
echo -e "${WHITE}💡 PRÓXIMOS PASOS:${NC}"
echo -e "  1. Revisar reporte ejecutivo para hallazgos clave"
echo -e "  2. Implementar recomendaciones de optimización"
echo -e "  3. Configurar JMeter real para pruebas de producción"
echo -e "  4. Integrar con pipeline CI/CD"

echo ""
echo -e "${WHITE}🔗 REPOSITORIO:${NC}"
echo -e "  Añade todo el directorio 'evidencias' a tu repositorio Git"
echo -e "  Incluye capturas de pantalla de los reportes HTML"

# Intentar abrir el reporte principal (solo en sistemas con interfaz gráfica)
if [ -f "evidencias/graficas/reporte-metricas.html" ]; then
    echo ""
    print_step "Intentando abrir reporte principal..."
    
    if command -v xdg-open &> /dev/null; then
        xdg-open evidencias/graficas/reporte-metricas.html 2>/dev/null &
    elif command -v open &> /dev/null; then
        open evidencias/graficas/reporte-metricas.html 2>/dev/null &
    else
        echo -e "${YELLOW}📄 Abre manualmente: evidencias/graficas/reporte-metricas.html${NC}"
    fi
fi

# Mostrar estructura final
echo ""
print_header "📂 ESTRUCTURA FINAL GENERADA"

if command -v tree &> /dev/null; then
    tree evidencias 2>/dev/null || find evidencias -type f 2>/dev/null | sort
else
    find evidencias -type f 2>/dev/null | sort
fi

# Footer final
echo ""
print_header "🎯 ¡FRAMEWORK DE EVIDENCIAS API MEDIPLUS COMPLETADO EXITOSAMENTE!"
echo -e "${WHITE}👥 Desarrollado por: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez${NC}"
echo -e "${WHITE}🕒 Finalizado: $(date '+%d/%m/%Y %H:%M:%S')${NC}"
echo -e "${WHITE}📧 Para soporte: anarriag@gmail.com, Jacobo.bustos.22@gmail.com, umancl@gmail.com${NC}"

echo ""
echo -e "${GREEN}🎉 ¡Proceso completado! Revisa los archivos generados en el directorio 'evidencias'${NC}"
echo ""