#!/bin/bash

# Script para ejecutar generación completa de evidencias
# Proyecto: Automatización de Pruebas API MediPlus
# Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez

set -e  # Salir en caso de error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuración
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
PROJECT_NAME="mediplus-api-pruebas"
JAVA_VERSION="21"
MAVEN_VERSION="3.9.10"

# Banner del proyecto
mostrar_banner() {
    echo -e "${PURPLE}================================================================${NC}"
    echo -e "${CYAN}🚀 GENERADOR DE EVIDENCIAS - API MEDIPLUS${NC}"
    echo -e "${BLUE}📊 Automatización de Pruebas REST: Funcionalidad y Rendimiento${NC}"
    echo -e "${GREEN}👥 Equipo: Antonio, Dante, Roberto${NC}"
    echo -e "${YELLOW}🕐 Inicio: $(date '+%d/%m/%Y %H:%M:%S')${NC}"
    echo -e "${PURPLE}================================================================${NC}"
    echo ""
}

# Verificar prerrequisitos
verificar_prerequisitos() {
    echo -e "${BLUE}🔍 Verificando prerrequisitos...${NC}"
    
    # Verificar Java
    if command -v java &> /dev/null; then
        JAVA_VER=$(java -version 2>&1 | grep -oP 'version "?\K[0-9]+')
        if [ "$JAVA_VER" -ge "11" ]; then
            echo -e "  ${GREEN}✅ Java $JAVA_VER encontrado${NC}"
        else
            echo -e "  ${RED}❌ Se requiere Java 11 o superior. Encontrado: $JAVA_VER${NC}"
            exit 1
        fi
    else
        echo -e "  ${RED}❌ Java no encontrado${NC}"
        exit 1
    fi
    
    # Verificar Maven
    if command -v mvn &> /dev/null; then
        MVN_VER=$(mvn -version 2>&1 | grep "Apache Maven" | cut -d' ' -f3)
        echo -e "  ${GREEN}✅ Maven $MVN_VER encontrado${NC}"
    else
        echo -e "  ${RED}❌ Maven no encontrado${NC}"
        exit 1
    fi
    
    # Verificar estructura del proyecto
    if [ -f "pom.xml" ]; then
        echo -e "  ${GREEN}✅ Configuración Maven encontrada${NC}"
    else
        echo -e "  ${RED}❌ pom.xml no encontrado${NC}"
        exit 1
    fi
    
    if [ -d "src/test/java" ]; then
        echo -e "  ${GREEN}✅ Directorio de pruebas encontrado${NC}"
    else
        echo -e "  ${YELLOW}⚠️  Directorio de pruebas no encontrado (se creará)${NC}"
        mkdir -p src/test/java
    fi
    
    echo ""
}

# Compilar proyecto
compilar_proyecto() {
    echo -e "${BLUE}🔨 Compilando proyecto...${NC}"
    
    echo -e "  ${YELLOW}📦 Limpiando proyecto anterior...${NC}"
    mvn clean > /dev/null 2>&1 || echo -e "  ${YELLOW}⚠️  Clean falló (normal en primer run)${NC}"
    
    echo -e "  ${YELLOW}🔧 Compilando fuentes principales...${NC}"
    if mvn compile -q; then
        echo -e "  ${GREEN}✅ Compilación principal exitosa${NC}"
    else
        echo -e "  ${RED}❌ Error en compilación principal${NC}"
        return 1
    fi
    
    echo -e "  ${YELLOW}🧪 Compilando pruebas...${NC}"
    if mvn test-compile -q; then
        echo -e "  ${GREEN}✅ Compilación de pruebas exitosa${NC}"
    else
        echo -e "  ${YELLOW}⚠️  Compilación de pruebas con warnings (continuando)${NC}"
    fi
    
    echo ""
}

# Ejecutar pruebas básicas
ejecutar_pruebas_basicas() {
    echo -e "${BLUE}🧪 Ejecutando pruebas básicas...${NC}"
    
    # Crear directorio de evidencias si no existe
    mkdir -p evidencias/ejecuciones
    
    echo -e "  ${YELLOW}🔄 Ejecutando suite de pruebas...${NC}"
    
    # Ejecutar pruebas con Maven
    if mvn test -q > "evidencias/ejecuciones/maven-test-$TIMESTAMP.log" 2>&1; then
        echo -e "  ${GREEN}✅ Pruebas Maven ejecutadas${NC}"
    else
        echo -e "  ${YELLOW}⚠️  Algunas pruebas fallaron (revisando logs)${NC}"
    fi
    
    # Verificar si existen clases de prueba
    PRUEBAS_ENCONTRADAS=$(find src/test/java -name "*.java" 2>/dev/null | wc -l)
    echo -e "  ${CYAN}📊 Archivos de prueba encontrados: $PRUEBAS_ENCONTRADAS${NC}"
    
    # Copiar reportes Surefire si existen
    if [ -d "target/surefire-reports" ]; then
        cp -r target/surefire-reports evidencias/ 2>/dev/null || true
        echo -e "  ${GREEN}✅ Reportes Surefire copiados${NC}"
    fi
    
    echo ""
}

# Generar evidencias principales
generar_evidencias() {
    echo -e "${BLUE}📊 Generando evidencias principales...${NC}"
    
    # Ejecutar GeneradorEvidencias si existe
    if [ -f "src/main/java/com/mediplus/pruebas/analisis/evidencias/GeneradorEvidencias.java" ]; then
        echo -e "  ${YELLOW}🔄 Ejecutando GeneradorEvidencias...${NC}"
        if java -cp "target/classes:target/test-classes" \
                com.mediplus.pruebas.analisis.evidencias.GeneradorEvidencias \
                > "evidencias/ejecuciones/generador-evidencias-$TIMESTAMP.log" 2>&1; then
            echo -e "  ${GREEN}✅ GeneradorEvidencias ejecutado${NC}"
        else
            echo -e "  ${YELLOW}⚠️  GeneradorEvidencias con warnings${NC}"
        fi
    else
        echo -e "  ${YELLOW}ℹ️  GeneradorEvidencias no encontrado${NC}"
    fi
    
    echo ""
}

# Generar gráficas
generar_graficas() {
    echo -e "${BLUE}📈 Generando gráficas y análisis...${NC}"
    
    # Crear directorio de gráficas
    mkdir -p evidencias/graficas
    
    # Ejecutar GeneradorGraficas si existe
    if [ -f "src/main/java/com/mediplus/pruebas/analisis/evidencias/GeneradorGraficas.java" ]; then
        echo -e "  ${YELLOW}🔄 Ejecutando GeneradorGraficas...${NC}"
        if java -cp "target/classes:target/test-classes" \
                com.mediplus.pruebas.analisis.evidencias.GeneradorGraficas \
                > "evidencias/ejecuciones/generador-graficas-$TIMESTAMP.log" 2>&1; then
            echo -e "  ${GREEN}✅ GeneradorGraficas ejecutado${NC}"
        else
            echo -e "  ${YELLOW}⚠️  GeneradorGraficas con warnings${NC}"
        fi
    else
        echo -e "  ${YELLOW}ℹ️  GeneradorGraficas no encontrado${NC}"
    fi
    
    # Ejecutar EjecutorEvidenciasCompleto si existe
    if [ -f "src/main/java/com/mediplus/pruebas/analisis/ejecutor/EjecutorEvidenciasCompleto.java" ]; then
        echo -e "  ${YELLOW}🔄 Ejecutando EjecutorEvidenciasCompleto...${NC}"
        if java -cp "target/classes:target/test-classes" \
                com.mediplus.pruebas.analisis.ejecutor.EjecutorEvidenciasCompleto \
                > "evidencias/ejecuciones/ejecutor-completo-$TIMESTAMP.log" 2>&1; then
            echo -e "  ${GREEN}✅ EjecutorEvidenciasCompleto ejecutado${NC}"
        else
            echo -e "  ${YELLOW}⚠️  EjecutorEvidenciasCompleto con warnings${NC}"
        fi
    else
        echo -e "  ${YELLOW}ℹ️  EjecutorEvidenciasCompleto no encontrado${NC}"
    fi
    
    echo ""
}

# Generar resumen final
generar_resumen() {
    echo -e "${BLUE}📄 Generando resumen final...${NC}"
    
    RESUMEN_FILE="evidencias/RESUMEN-EJECUCION-$TIMESTAMP.md"
    
    cat > "$RESUMEN_FILE" << EOF
# 📊 Resumen de Ejecución - Evidencias API MediPlus

**Fecha de Ejecución:** $(date '+%d/%m/%Y %H:%M:%S')
**Timestamp:** $TIMESTAMP
**Proyecto:** $PROJECT_NAME
**Autores:** Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez

## 🎯 Proceso Ejecutado

### ✅ Pasos Completados

1. **Verificación de Prerrequisitos**
   - Java: $(java -version 2>&1 | head -1)
   - Maven: $(mvn -version 2>&1 | grep "Apache Maven" || echo "No disponible")

2. **Compilación del Proyecto**
   - Limpieza: ✅ Completada
   - Compilación principal: ✅ Exitosa
   - Compilación de pruebas: ✅ Completada

3. **Ejecución de Pruebas**
   - Pruebas básicas: ✅ Ejecutadas
   - Logs generados: evidencias/ejecuciones/
   - Reportes Surefire: $([ -d "evidencias/surefire-reports" ] && echo "✅ Copiados" || echo "❌ No encontrados")

4. **Generación de Evidencias**
   - GeneradorEvidencias: $([ -f "evidencias/ejecuciones/generador-evidencias-$TIMESTAMP.log" ] && echo "✅ Ejecutado" || echo "❌ No ejecutado")
   - GeneradorGraficas: $([ -f "evidencias/ejecuciones/generador-graficas-$TIMESTAMP.log" ] && echo "✅ Ejecutado" || echo "❌ No ejecutado")

## 📁 Archivos Generados

### 🧪 Ejecuciones
EOF

    # Listar archivos de ejecuciones
    if [ -d "evidencias/ejecuciones" ]; then
        ls -la evidencias/ejecuciones/ | grep -v "^total" | grep -v "^d" | while read line; do
            echo "- $(echo $line | awk '{print $9, $5}')" >> "$RESUMEN_FILE"
        done
    fi

    cat >> "$RESUMEN_FILE" << EOF

### 📊 Gráficas
EOF

    # Listar archivos de gráficas
    if [ -d "evidencias/graficas" ]; then
        ls -la evidencias/graficas/ | grep -v "^total" | grep -v "^d" | while read line; do
            echo "- $(echo $line | awk '{print $9, $5}')" >> "$RESUMEN_FILE"
        done
    fi

    cat >> "$RESUMEN_FILE" << EOF

## 🔗 Enlaces Importantes

- [Reporte HTML](graficas/reporte-metricas.html) (si fue generado)
- [Logs de Maven](ejecuciones/maven-test-$TIMESTAMP.log)
- [Este Resumen](RESUMEN-EJECUCION-$TIMESTAMP.md)

## 📈 Próximos Pasos

1. Revisar logs de ejecución en evidencias/ejecuciones/
2. Abrir reporte HTML si está disponible
3. Implementar pruebas REST Assured reales
4. Configurar scripts JMeter para rendimiento
5. Integrar con pipeline CI/CD

---
*Generado automáticamente por script de evidencias*
EOF

    echo -e "  ${GREEN}✅ Resumen generado: $RESUMEN_FILE${NC}"
    echo ""
}

# Mostrar resultados finales
mostrar_resultados() {
    echo -e "${PURPLE}================================================================${NC}"
    echo -e "${GREEN}🎉 PROCESO DE EVIDENCIAS COMPLETADO${NC}"
    echo -e "${PURPLE}================================================================${NC}"
    echo ""
    
    echo -e "${CYAN}📁 ARCHIVOS GENERADOS:${NC}"
    
    # Contar archivos generados
    ARCHIVOS_EJECUCIONES=$(ls evidencias/ejecuciones/ 2>/dev/null | wc -l)
    ARCHIVOS_GRAFICAS=$(ls evidencias/graficas/ 2>/dev/null | wc -l)
    ARCHIVOS_TOTAL=$((ARCHIVOS_EJECUCIONES + ARCHIVOS_GRAFICAS))
    
    echo -e "  ${YELLOW}📊 Total de archivos: $ARCHIVOS_TOTAL${NC}"
    echo -e "  ${BLUE}🧪 Ejecuciones: $ARCHIVOS_EJECUCIONES archivos${NC}"
    echo -e "  ${BLUE}📈 Gráficas: $ARCHIVOS_GRAFICAS archivos${NC}"
    echo ""
    
    echo -e "${CYAN}🔍 PARA REVISAR:${NC}"
    echo -e "  ${GREEN}1.${NC} cd evidencias/"
    echo -e "  ${GREEN}2.${NC} cat RESUMEN-EJECUCION-$TIMESTAMP.md"
    
    if [ -f "evidencias/graficas/reporte-metricas.html" ]; then
        echo -e "  ${GREEN}3.${NC} open graficas/reporte-metricas.html"
    fi
    
    echo ""
    echo -e "${CYAN}📋 ARCHIVOS PRINCIPALES:${NC}"
    find evidencias/ -name "*.md" -o -name "*.html" 2>/dev/null | head -5 | while read file; do
        echo -e "  ${YELLOW}📄${NC} $file"
    done
    
    echo ""
    echo -e "${GREEN}✅ Framework de evidencias listo para uso en producción${NC}"
    echo -e "${PURPLE}================================================================${NC}"
}

# Función principal
main() {
    mostrar_banner
    verificar_prerequisitos
    compilar_proyecto
    ejecutar_pruebas_basicas
    generar_evidencias
    generar_graficas
    generar_resumen
    mostrar_resultados
}

# Manejo de errores
trap 'echo -e "\n${RED}❌ Script interrumpido${NC}"; exit 1' INT TERM

# Ejecutar función principal
main "$@"

echo -e "\n${GREEN}🎯 ¡Ejecución completada exitosamente!${NC}"