DIRECTORIO_RESULTADOS="resultados"

echo "🧪 Generando datos de prueba para análisis de métricas"
echo "====================================================="

mkdir -p "$DIRECTORIO_RESULTADOS"

# Función para generar archivo JTL simulado
generar_jtl() {
    local archivo=$1
    local usuarios=$2
    local escenario=$3
    local tasa_error=$4
    local tiempo_base=$5
    
    echo "📝 Generando: $archivo"
    
    # Header JTL
    echo "timeStamp,elapsed,label,responseCode,responseMessage,threadName,dataType,success,failureMessage,bytes,sentBytes,grpThreads,allThreads,URL,Filename,latency,encoding,SampleCount,ErrorCount,hostname,idleTime" > "$DIRECTORIO_RESULTADOS/$archivo"
    
    # Generar registros simulados
    for ((i=1; i<=200; i++)); do
        timestamp=$((1703001000000 + i * 1000))
        
        # Simular tiempo de respuesta con variación
        variacion=$((RANDOM % 500))
        tiempo_respuesta=$((tiempo_base + variacion))
        
        # Simular errores según tasa
        if [[ $((RANDOM % 100)) -lt $tasa_error ]]; then
            response_code=500
            success="false"
            failure_message="Internal Server Error"
        else
            response_code=200
            success="true"
            failure_message=""
        fi
        
        bytes=$((1024 + RANDOM % 2048))
        thread_name="Thread Group 1-$((i % usuarios + 1))"
        
        echo "$timestamp,$tiempo_respuesta,$escenario,$response_code,OK,$thread_name,,${success},$failure_message,$bytes,256,$usuarios,$usuarios,http://api.mediplus.com/$escenario,,50,UTF-8,1,0,localhost,0" >> "$DIRECTORIO_RESULTADOS/$archivo"
    done
}

# Generar archivos para diferentes escenarios
generar_jtl "get_masivo_10u.jtl" 10 "GET_Pacientes" 0 245
generar_jtl "get_masivo_50u.jtl" 50 "GET_Pacientes" 2 890
generar_jtl "get_masivo_100u.jtl" 100 "GET_Pacientes" 9 2150

generar_jtl "post_masivo_10u.jtl" 10 "POST_Pacientes" 0 380
generar_jtl "post_masivo_50u.jtl" 50 "POST_Pacientes" 4 1250
generar_jtl "post_masivo_100u.jtl" 100 "POST_Pacientes" 15 3450

generar_jtl "mixto_10u.jtl" 10 "Mixto" 0 315
generar_jtl "mixto_50u.jtl" 50 "Mixto" 4 1120
generar_jtl "mixto_100u.jtl" 100 "Mixto" 12 2890

echo ""
echo "✅ Datos de prueba generados en: $DIRECTORIO_RESULTADOS"
echo "📊 Archivos creados:"
ls -la "$DIRECTORIO_RESULTADOS"/*.jtl