#!/bin/bash

# Script para reparar el proyecto Maven y hacerlo funcional
# Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🔧 REPARANDO PROYECTO MEDIPLUS${NC}"
echo "======================================================================"

# Hacer backup del pom.xml actual
hacer_backup() {
    echo -e "${YELLOW}💾 Haciendo backup del pom.xml actual...${NC}"
    
    if [ -f "pom.xml" ]; then
        cp pom.xml "pom-backup-$(date +%Y%m%d_%H%M%S).xml"
        echo -e "${GREEN}✅ Backup creado${NC}"
    fi
}

# Limpiar completamente el proyecto
limpiar_proyecto() {
    echo -e "${YELLOW}🧹 Limpiando proyecto completamente...${NC}"
    
    # Limpiar con Maven si es posible
    mvn clean -q 2>/dev/null || echo "Maven clean falló, continuando..."
    
    # Limpiar manualmente
    rm -rf target/ 2>/dev/null || true
    rm -rf .mvn/ 2>/dev/null || true
    rm -rf logs/ 2>/dev/null || true
    
    echo -e "${GREEN}✅ Proyecto limpio${NC}"
}

# Crear estructura básica
crear_estructura() {
    echo -e "${YELLOW}📁 Creando estructura básica...${NC}"
    
    # Directorios Maven estándar
    mkdir -p src/main/java/com/mediplus/pruebas/analisis
    mkdir -p src/main/resources
    mkdir -p src/test/java/com/mediplus/pruebas/analisis
    mkdir -p src/test/resources
    
    # Directorios del proyecto
    mkdir -p target/classes
    mkdir -p resultados
    mkdir -p reportes
    mkdir -p logs
    mkdir -p datos
    
    echo -e "${GREEN}✅ Estructura creada${NC}"
}

# Verificar archivos Java
verificar_archivos_java() {
    echo -e "${YELLOW}🔍 Verificando archivos Java...${NC}"
    
    local java_files=$(find src -name "*.java" 2>/dev/null | wc -l)
    echo "📊 Archivos Java encontrados: $java_files"
    
    if [ "$java_files" -gt 0 ]; then
        echo "📁 Archivos principales:"
        find src -name "*.java" | head -5 | while read file; do
            echo "  - $file"
        done
        echo -e "${GREEN}✅ Archivos Java presentes${NC}"
    else
        echo -e "${YELLOW}⚠️  No se encontraron archivos Java${NC}"
    fi
}

# Compilar con el nuevo pom.xml
compilar_proyecto() {
    echo -e "${YELLOW}🔨 Compilando con configuración simplificada...${NC}"
    
    # Intentar compilación básica
    if mvn compile -q -DskipTests; then
        echo -e "${GREEN}✅ Compilación exitosa${NC}"
        return 0
    else
        echo -e "${YELLOW}⚠️  Compilación Maven falló, intentando manual...${NC}"
        
        # Compilación manual
        if compilar_manual; then
            echo -e "${GREEN}✅ Compilación manual exitosa${NC}"
            return 0
        else
            echo -e "${RED}❌ Compilación falló${NC}"
            return 1
        fi
    fi
}

# Compilación manual
compilar_manual() {
    local src_dir="src/main/java"
    local target_dir="target/classes"
    
    if [ ! -d "$src_dir" ]; then
        return 1
    fi
    
    mkdir -p "$target_dir"
    
    # Buscar archivos Java
    local java_files=$(find "$src_dir" -name "*.java" 2>/dev/null)
    
    if [ -z "$java_files" ]; then
        return 1
    fi
    
    # Compilar
    if javac -d "$target_dir" -cp "$target_dir" $java_files 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

# Ejecutar pruebas básicas
ejecutar_pruebas_basicas() {
    echo -e "${YELLOW}🧪 Ejecutando pruebas básicas...${NC}"
    
    # Intentar ejecutar PruebasBasicas
    if [ -f "target/classes/com/mediplus/pruebas/analisis/test/PruebasBasicas.class" ]; then
        if java -cp target/classes com.mediplus.pruebas.analisis.test.PruebasBasicas > logs/pruebas-reparacion.log 2>&1; then
            echo -e "${GREEN}✅ Pruebas básicas exitosas${NC}"
            tail -3 logs/pruebas-reparacion.log
        else
            echo -e "${YELLOW}⚠️  Pruebas con errores (ver logs/pruebas-reparacion.log)${NC}"
        fi
    else
        echo -e "${YELLOW}⚠️  PruebasBasicas no encontrado${NC}"
    fi
}

# Generar JAR funcional
generar_jar() {
    echo -e "${YELLOW}📦 Generando JAR...${NC}"
    
    if mvn package -DskipTests -q; then
        echo -e "${GREEN}✅ JAR generado con Maven${NC}"
        if [ -f "target/api-pruebas-automatizadas.jar" ]; then
            local size=$(du -h "target/api-pruebas-automatizadas.jar" | cut -f1)
            echo "📊 Tamaño: $size"
        fi
    else
        echo -e "${YELLOW}⚠️  Maven package falló, generando JAR manual...${NC}"
        generar_jar_manual
    fi
}

# Generar JAR manual
generar_jar_manual() {
    local jar_file="target/api-pruebas-automatizadas-manual.jar"
    
    # Crear MANIFEST
    cat > target/MANIFEST.MF << EOF
Manifest-Version: 1.0
Main-Class: com.mediplus.pruebas.analisis.test.PruebasBasicas
Class-Path: .
EOF
    
    # Crear JAR
    if cd target/classes && jar cfm "../api-pruebas-automatizadas-manual.jar" ../MANIFEST.MF . 2>/dev/null; then
        cd ../..
        echo -e "${GREEN}✅ JAR manual generado: $jar_file${NC}"
    else
        cd ../.. 2>/dev/null || true
        echo -e "${RED}❌ Error generando JAR manual${NC}"
    fi
}

# Mostrar resumen final
mostrar_resumen() {
    echo ""
    echo -e "${BLUE}📋 RESUMEN DE REPARACIÓN${NC}"
    echo "======================================================================"
    
    echo "📁 Estado de archivos:"
    
    # Verificar compilación
    if [ -d "target/classes" ] && [ "$(find target/classes -name "*.class" | wc -l)" -gt 0 ]; then
        echo -e "   ✅ Clases compiladas: target/classes/"
    else
        echo -e "   ❌ Clases NO compiladas"
    fi
    
    # Verificar JAR
    if [ -f "target/api-pruebas-automatizadas.jar" ]; then
        echo -e "   ✅ JAR Maven: target/api-pruebas-automatizadas.jar"
    elif [ -f "target/api-pruebas-automatizadas-manual.jar" ]; then
        echo -e "   ✅ JAR Manual: target/api-pruebas-automatizadas-manual.jar"
    else
        echo -e "   ❌ JAR NO generado"
    fi
    
    # Verificar estructura
    if [ -d "resultados" ] && [ -d "logs" ]; then
        echo -e "   ✅ Estructura de directorios: OK"
    else
        echo -e "   ❌ Estructura incompleta"
    fi
    
    echo ""
    echo "🚀 Para ejecutar:"
    echo "   java -cp target/classes com.mediplus.pruebas.analisis.test.PruebasBasicas"
    echo "   mvn test -Dtest=PruebasBasicas"
    echo ""
    echo "📊 Para generar reportes:"
    echo "   mvn site"
    echo "   mvn jacoco:report"
    echo ""
}

# Función principal
main() {
    local operacion=${1:-full}
    
    case "$operacion" in
        "full"|"completa")
            hacer_backup
            limpiar_proyecto
            crear_estructura
            verificar_archivos_java
            compilar_proyecto
            ejecutar_pruebas_basicas
            generar_jar
            mostrar_resumen
            echo -e "${GREEN}🎉 ¡Reparación completa!${NC}"
            ;;
        "compile"|"compilar")
            limpiar_proyecto
            compilar_proyecto
            ;;
        "clean"|"limpiar")
            limpiar_proyecto
            crear_estructura
            ;;
        "test"|"pruebas")
            ejecutar_pruebas_basicas
            ;;
        "help"|"ayuda")
            echo "📖 USO:"
            echo "   $0 full      - Reparación completa"
            echo "   $0 compile   - Solo compilar"
            echo "   $0 clean     - Solo limpiar"
            echo "   $0 test      - Solo pruebas"
            echo "   $0 help      - Mostrar ayuda"
            ;;
        *)
            echo -e "${RED}❌ Opción no válida: $operacion${NC}"
            exit 1
            ;;
    esac
}

main "$@"