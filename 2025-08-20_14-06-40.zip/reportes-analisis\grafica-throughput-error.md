# Gráfica 2: Throughput vs Tasa de Error

```
Tasa de Error (%)
  6 │
  5 │                                    ●COMBINADO_100
  4 │
  3 │
  2 │           ●POST_50
  1 │
  0 │●GET_10
    └────────────────────────────────────────────────
     0    50   100  150  200  250  300   Throughput (req/seg)

Datos exactos:
• GET_10_USUARIOS     : 89,7 req/seg, 0,2% error
• POST_50_USUARIOS    : 156,4 req/seg, 1,8% error
• COMBINADO_100_USUARIOS: 287,9 req/seg, 5,4% error
```
