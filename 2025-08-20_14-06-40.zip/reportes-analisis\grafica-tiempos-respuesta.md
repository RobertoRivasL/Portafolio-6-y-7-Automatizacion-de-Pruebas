# Gráfica 1: Comparación Tiempos de Respuesta

```
Tiempo de Respuesta (ms)
     0    500   1000  1500  2000  2500  3000
     |     |     |     |     |     |     |
GET_10_USUARIOS │████● 245,5 ms (Promedio)
                │░░░░░░░▲ 398,5 ms (P95)

POST_50_USUARIOS │█████████████████████████● 1250,3 ms (Promedio)
                │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▲ 2150,8 ms (P95)

COMBINADO_100_USUARIOS │█████████████████● 890,7 ms (Promedio)
                │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▲ 1567,8 ms (P95)

```
