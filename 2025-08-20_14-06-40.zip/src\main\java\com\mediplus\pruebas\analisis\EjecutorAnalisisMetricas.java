package com.mediplus.pruebas.analisis;

import com.mediplus.pruebas.analisis.modelo.MetricaRendimiento;
import com.mediplus.pruebas.analisis.servicio.LectorArchivosJTL;
import com.mediplus.pruebas.analisis.configuracion.ConfiguracionAplicacion;

import java.nio.file.Path;
import java.nio.file.Files;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * Clase principal para ejecutar el análisis de métricas de rendimiento
 * Punto de entrada de la aplicación de análisis
 * 
 * @author Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez
 */
public class EjecutorAnalisisMetricas {

    private static final Logger LOGGER = Logger.getLogger(EjecutorAnalisisMetricas.class.getName());

    public static void main(String[] args) {
        try {
            EjecutorAnalisisMetricas ejecutor = new EjecutorAnalisisMetricas();
            ejecutor.ejecutarAnalisisCompleto();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error durante la ejecución del análisis", e);
            System.exit(1);
        }
    }

    /**
     * Ejecuta el análisis completo de métricas
     */
    public void ejecutarAnalisisCompleto() throws Exception {
        LOGGER.info("🚀 Iniciando análisis de métricas de rendimiento API MediPlus");

        // Configuración de directorios
        ConfiguracionAplicacion configuracion = ConfiguracionAplicacion.obtenerInstancia();
        Path directorioResultados = configuracion.obtenerDirectorioResultados();
        Path directorioReportes = configuracion.obtenerDirectorioReportes();

        // Validar que existan los directorios
        validarDirectorios(directorioResultados);

        // Inicializar lector de archivos JTL
        LectorArchivosJTL lectorJTL = new LectorArchivosJTL();

        // Procesar archivos JTL
        LOGGER.info("📊 Procesando archivos de resultados JTL...");
        List<MetricaRendimiento> metricas = procesarArchivosJTL(directorioResultados, lectorJTL);

        if (metricas.isEmpty()) {
            LOGGER.warning("⚠️ No se encontraron métricas válidas para analizar");
            System.out.println("⚠️ No se encontraron archivos .jtl para procesar");
            return;
        }

        LOGGER.info(String.format("✅ Se procesaron %d métricas exitosamente", metricas.size()));

        // Mostrar resumen en consola
        mostrarResumenEnConsola(metricas);

        // Generar análisis comparativo
        LOGGER.info("🔍 Generando análisis comparativo...");
        ComparacionMetricas comparacion = compararMetricas(metricas);

        // Generar reportes
        LOGGER.info("📋 Generando reportes completos...");
        generarReporteCompleto(metricas, directorioReportes);

        // Mostrar recomendaciones principales
        mostrarRecomendacionesPrincipales(comparacion);

        LOGGER.info("🎉 Análisis completado exitosamente. Revisa el directorio 'reportes' para ver los resultados detallados.");
    }

    private void validarDirectorios(Path directorioResultados) {
        if (!directorioResultados.toFile().exists()) {
            LOGGER.severe("❌ El directorio de resultados no existe: " + directorioResultados);
            throw new IllegalArgumentException("Directorio de resultados no encontrado: " + directorioResultados);
        }
    }

    private List<MetricaRendimiento> procesarArchivosJTL(Path directorioResultados, LectorArchivosJTL lectorJTL) {
        List<MetricaRendimiento> metricas = new ArrayList<>();
        
        try {
            Files.list(directorioResultados)
                .filter(p -> p.toString().endsWith(".jtl"))
                .forEach(archivo -> {
                    try {
                        System.out.println("📊 Procesando: " + archivo.getFileName());
                        MetricaRendimiento metrica = lectorJTL.procesarArchivoJTL(archivo);
                        if (metrica != null) {
                            metricas.add(metrica);
                        }
                    } catch (Exception e) {
                        System.err.println("⚠️ Error procesando " + archivo.getFileName() + ": " + e.getMessage());
                    }
                });
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error listando archivos JTL", e);
        }
        
        return metricas;
    }

    private void mostrarResumenEnConsola(List<MetricaRendimiento> metricas) {
        System.out.println("\n" + "=".repeat(80));
        System.out.println("📊 RESUMEN EJECUTIVO DE MÉTRICAS");
        System.out.println("=".repeat(80));

        System.out.printf("%-25s %-10s %-15s %-15s %-12s %-10s%n",
                "ESCENARIO", "USUARIOS", "TIEMPO PROM.", "THROUGHPUT", "ERROR %", "NIVEL");
        System.out.println("-".repeat(80));

        metricas.stream()
                .sorted(Comparator.comparing(MetricaRendimiento::getNombreEscenario)
                        .thenComparing(MetricaRendimiento::getUsuariosConcurrentes))
                .forEach(metrica -> System.out.printf("%-25s %-10d %-15s %-15s %-12s %-10s%n",
                        metrica.getNombreEscenario(),
                        metrica.getUsuariosConcurrentes(),
                        String.format("%.0f ms", metrica.getTiempoPromedioMs()),
                        String.format("%.1f req/s", metrica.getThroughputReqSeg()),
                        String.format("%.1f%%", metrica.getTasaErrorPorcentaje()),
                        metrica.evaluarNivelRendimiento().getDescripcion()));

        System.out.println("=".repeat(80));
    }

    private ComparacionMetricas compararMetricas(List<MetricaRendimiento> metricas) {
        // Análisis básico de comparación
        long escenariosCriticos = metricas.stream()
            .filter(m -> m.evaluarNivelRendimiento() == MetricaRendimiento.NivelRendimiento.MALO ||
                        m.evaluarNivelRendimiento() == MetricaRendimiento.NivelRendimiento.INACEPTABLE)
            .count();

        double tiempoPromedioGeneral = metricas.stream()
            .mapToDouble(MetricaRendimiento::getTiempoPromedioMs)
            .average().orElse(0.0);

        double throughputPromedio = metricas.stream()
            .mapToDouble(MetricaRendimiento::getThroughputReqSeg)
            .average().orElse(0.0);

        return new ComparacionMetricas(metricas, escenariosCriticos, tiempoPromedioGeneral, throughputPromedio);
    }

    private void generarReporteCompleto(List<MetricaRendimiento> metricas, Path directorioReportes) {
        try {
            Files.createDirectories(directorioReportes);
            
            // Aquí podrías integrar con GeneradorReportes si lo tienes
            System.out.println("📋 Reportes guardados en: " + directorioReportes.toAbsolutePath());
            
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error generando reportes", e);
        }
    }

    private void mostrarRecomendacionesPrincipales(ComparacionMetricas comparacion) {
        System.out.println("\n" + "=".repeat(80));
        System.out.println("💡 RECOMENDACIONES PRINCIPALES");
        System.out.println("=".repeat(80));

        List<String> recomendaciones = generarRecomendaciones(comparacion);
        
        for (int i = 0; i < recomendaciones.size(); i++) {
            System.out.println((i + 1) + ". " + recomendaciones.get(i));
        }

        System.out.println("\n=".repeat(80));
    }

    private List<String> generarRecomendaciones(ComparacionMetricas comparacion) {
        List<String> recomendaciones = new ArrayList<>();
        
        if (comparacion.getEscenariosCriticos() > 0) {
            recomendaciones.add("⚠️ Optimizar rendimiento: Se detectaron " + comparacion.getEscenariosCriticos() + 
                " escenarios con rendimiento crítico que requieren atención inmediata.");
        }
        
        if (comparacion.getTiempoPromedioGeneral() > 2000) {
            recomendaciones.add("🚀 Reducir latencia: El tiempo promedio de " + 
                String.format("%.0f ms", comparacion.getTiempoPromedioGeneral()) + 
                " excede los umbrales recomendados. Implementar cache y optimizar consultas.");
        }
        
        if (comparacion.getThroughputPromedio() < 20) {
            recomendaciones.add("📈 Mejorar throughput: El rendimiento actual de " +
                String.format("%.1f req/s", comparacion.getThroughputPromedio()) +
                " puede mejorarse con auto-scaling y balanceador de carga.");
        }
        
        if (recomendaciones.isEmpty()) {
            recomendaciones.add("✅ Rendimiento aceptable: El sistema muestra métricas dentro de rangos aceptables. " +
                "Continuar con monitoreo regular.");
        }
        
        return recomendaciones;
    }

    /**
     * Clase para almacenar resultados de comparación de métricas
     */
    public static class ComparacionMetricas {
        private final List<MetricaRendimiento> metricas;
        private final long escenariosCriticos;
        private final double tiempoPromedioGeneral;
        private final double throughputPromedio;

        public ComparacionMetricas(List<MetricaRendimiento> metricas, long escenariosCriticos, 
                                   double tiempoPromedioGeneral, double throughputPromedio) {
            this.metricas = metricas;
            this.escenariosCriticos = escenariosCriticos;
            this.tiempoPromedioGeneral = tiempoPromedioGeneral;
            this.throughputPromedio = throughputPromedio;
        }

        public List<MetricaRendimiento> getMetricas() { return metricas; }
        public long getEscenariosCriticos() { return escenariosCriticos; }
        public double getTiempoPromedioGeneral() { return tiempoPromedioGeneral; }
        public double getThroughputPromedio() { return throughputPromedio; }
    }
}