package com.mediplus.pruebas.analisis.jmeter;

import com.mediplus.pruebas.analisis.modelo.MetricaRendimiento;
import com.mediplus.pruebas.analisis.servicio.LectorArchivosJTL;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Generador de reportes HTML personalizados para el proyecto MediPlus
 * Crea reportes ejecutivos profesionales con análisis detallado
 * 
 * @author Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez
 */
public class GeneradorReporteHTML {

    private static final DateTimeFormatter FORMATO_FECHA = 
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    
    private final LectorArchivosJTL lectorJTL;

    public GeneradorReporteHTML() {
        this.lectorJTL = new LectorArchivosJTL();
    }

    /**
     * Genera un reporte consolidado HTML con todos los resultados JTL
     */
    public void generarReporteConsolidado(Path directorioResultados) throws IOException {
        System.out.println("📈 Generando reporte consolidado HTML...");
        
        // Leer todos los archivos .jtl
        List<MetricaRendimiento> todasLasMetricas = leerTodosLosArchivosJTL(directorioResultados);
        
        if (todasLasMetricas.isEmpty()) {
            System.out.println("⚠️ No se encontraron archivos .jtl para procesar");
            return;
        }
        
        // Generar reporte HTML
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
        Path archivoReporte = directorioResultados.resolve("reporte-ejecutivo-" + timestamp + ".html");
        
        try (BufferedWriter writer = Files.newBufferedWriter(archivoReporte)) {
            generarHTML(writer, todasLasMetricas, timestamp);
        }
        
        System.out.println("✅ Reporte consolidado generado: " + archivoReporte.toAbsolutePath());
        System.out.println("🌐 Abrir en navegador: file://" + archivoReporte.toAbsolutePath());
    }

    /**
     * Lee todos los archivos .jtl del directorio
     */
    private List<MetricaRendimiento> leerTodosLosArchivosJTL(Path directorio) {
        List<MetricaRendimiento> metricas = new ArrayList<>();
        
        try {
            Files.list(directorio)
                .filter(p -> p.toString().endsWith(".jtl"))
                .forEach(archivo -> {
                    try {
                        System.out.println("📊 Procesando: " + archivo.getFileName());
                        MetricaRendimiento metrica = lectorJTL.procesarArchivoJTL(archivo);
                        if (metrica != null) {
                            metricas.add(metrica);
                        }
                    } catch (Exception e) {
                        System.err.println("⚠️ Error procesando " + archivo.getFileName() + ": " + e.getMessage());
                    }
                });
        } catch (IOException e) {
            System.err.println("❌ Error leyendo directorio: " + e.getMessage());
        }
        
        return metricas;
    }

    /**
     * Genera el contenido HTML completo del reporte
     */
    private void generarHTML(BufferedWriter writer, List<MetricaRendimiento> metricas, String timestamp) throws IOException {
        // Usar text blocks para evitar problemas con comillas
        escrituraCabeceraHTML(writer);
        escrituraEncabezadoReporte(writer, timestamp);
        escrituraResumenEjecutivo(writer, metricas);
        escrituraTablaDetallada(writer, metricas);
        escrituraRecomendaciones(writer, metricas);
        escrituraConclusiones(writer, metricas);
        escrituraPieHTML(writer);
    }

    private void escrituraCabeceraHTML(BufferedWriter writer) throws IOException {
        writer.write("<!DOCTYPE html>\n");
        writer.write("<html lang=\"es\">\n");
        writer.write("<head>\n");
        writer.write("<meta charset=\"UTF-8\">\n");
        writer.write("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n");
        writer.write("<title>Reporte Ejecutivo - Pruebas de Rendimiento API MediPlus</title>\n");
        writer.write("<style>\n");
        writer.write("body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }\n");
        writer.write(".container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }\n");
        writer.write(".header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }\n");
        writer.write(".section { background: white; margin: 20px 0; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }\n");
        writer.write("table { width: 100%; border-collapse: collapse; margin: 20px 0; }\n");
        writer.write("th { background: #667eea; color: white; padding: 12px; text-align: left; }\n");
        writer.write("td { padding: 10px; border-bottom: 1px solid #eee; }\n");
        writer.write("tr:hover { background-color: #f8f9fa; }\n");
        writer.write(".excelente { background-color: #d4edda; color: #155724; padding: 4px 8px; border-radius: 4px; }\n");
        writer.write(".bueno { background-color: #d1ecf1; color: #0c5460; padding: 4px 8px; border-radius: 4px; }\n");
        writer.write(".regular { background-color: #fff3cd; color: #856404; padding: 4px 8px; border-radius: 4px; }\n");
        writer.write(".malo { background-color: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 4px; }\n");
        writer.write(".inaceptable { background-color: #f5c6cb; color: #721c24; padding: 4px 8px; border-radius: 4px; }\n");
        writer.write(".recomendacion { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 10px 0; }\n");
        writer.write("</style>\n");
        writer.write("</head>\n");
        writer.write("<body>\n");
    }

    private void escrituraEncabezadoReporte(BufferedWriter writer, String timestamp) throws IOException {
        writer.write("<div class=\"container\">\n");
        writer.write("<div class=\"header\">\n");
        writer.write("<h1>Reporte Ejecutivo de Rendimiento</h1>\n");
        writer.write("<h2>API REST MediPlus - Pruebas de Carga</h2>\n");
        writer.write("<p>Generado el: " + LocalDateTime.now().format(FORMATO_FECHA) + "</p>\n");
        writer.write("<p>Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez</p>\n");
        writer.write("</div>\n");
    }

    private void escrituraResumenEjecutivo(BufferedWriter writer, List<MetricaRendimiento> metricas) throws IOException {
        if (metricas.isEmpty()) {
            writer.write("<div class=\"section\"><h2>Resumen Ejecutivo</h2><p>No hay datos para mostrar</p></div>\n");
            return;
        }
        
        int totalPruebas = metricas.size();
        long escenariosCriticos = metricas.stream()
            .filter(m -> m.evaluarNivelRendimiento() == MetricaRendimiento.NivelRendimiento.MALO ||
                        m.evaluarNivelRendimiento() == MetricaRendimiento.NivelRendimiento.INACEPTABLE)
            .count();
        
        double tiempoPromedioGeneral = metricas.stream()
            .mapToDouble(MetricaRendimiento::getTiempoPromedioMs)
            .average()
            .orElse(0.0);
            
        double throughputPromedio = metricas.stream()
            .mapToDouble(MetricaRendimiento::getThroughputReqSeg)
            .average()
            .orElse(0.0);
            
        double tasaErrorPromedio = metricas.stream()
            .mapToDouble(MetricaRendimiento::getTasaErrorPorcentaje)
            .average()
            .orElse(0.0);
        
        writer.write("<div class=\"section\">\n");
        writer.write("<h2>Resumen Ejecutivo</h2>\n");
        writer.write("<table>\n");
        writer.write("<tr><th>Métrica</th><th>Valor</th></tr>\n");
        writer.write("<tr><td>Total de Pruebas</td><td>" + totalPruebas + "</td></tr>\n");
        writer.write("<tr><td>Escenarios Críticos</td><td>" + escenariosCriticos + "</td></tr>\n");
        writer.write("<tr><td>Tiempo Promedio</td><td>" + String.format("%.0f ms", tiempoPromedioGeneral) + "</td></tr>\n");
        writer.write("<tr><td>Throughput Promedio</td><td>" + String.format("%.1f req/s", throughputPromedio) + "</td></tr>\n");
        writer.write("<tr><td>Tasa de Error</td><td>" + String.format("%.1f%%", tasaErrorPromedio) + "</td></tr>\n");
        writer.write("</table>\n");
        writer.write("</div>\n");
    }

    private void escrituraTablaDetallada(BufferedWriter writer, List<MetricaRendimiento> metricas) throws IOException {
        writer.write("<div class=\"section\">\n");
        writer.write("<h2>Tabla Detallada de Métricas</h2>\n");
        writer.write("<table>\n");
        writer.write("<tr>\n");
        writer.write("<th>Escenario</th>\n");
        writer.write("<th>Usuarios</th>\n");
        writer.write("<th>Tiempo Promedio</th>\n");
        writer.write("<th>P90</th>\n");
        writer.write("<th>P95</th>\n");
        writer.write("<th>Throughput</th>\n");
        writer.write("<th>Tasa Error</th>\n");
        writer.write("<th>Nivel</th>\n");
        writer.write("</tr>\n");
        
        metricas.stream()
            .sorted(Comparator.comparing(MetricaRendimiento::getNombreEscenario)
                    .thenComparing(MetricaRendimiento::getUsuariosConcurrentes))
            .forEach(metrica -> {
                try {
                    String claseNivel = "nivel-" + metrica.evaluarNivelRendimiento().name().toLowerCase();
                    writer.write("<tr>\n");
                    writer.write("<td>" + metrica.getNombreEscenario() + "</td>\n");
                    writer.write("<td>" + metrica.getUsuariosConcurrentes() + "</td>\n");
                    writer.write("<td>" + String.format("%.0f ms", metrica.getTiempoPromedioMs()) + "</td>\n");
                    writer.write("<td>" + String.format("%.0f ms", metrica.getPercentil90Ms()) + "</td>\n");
                    writer.write("<td>" + String.format("%.0f ms", metrica.getPercentil95Ms()) + "</td>\n");
                    writer.write("<td>" + String.format("%.1f req/s", metrica.getThroughputReqSeg()) + "</td>\n");
                    writer.write("<td>" + String.format("%.1f%%", metrica.getTasaErrorPorcentaje()) + "</td>\n");
                    writer.write("<td><span class=\"" + claseNivel + "\">" + metrica.evaluarNivelRendimiento().getDescripcion() + "</span></td>\n");
                    writer.write("</tr>\n");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        
        writer.write("</table>\n");
        writer.write("</div>\n");
    }

    private void escrituraRecomendaciones(BufferedWriter writer, List<MetricaRendimiento> metricas) throws IOException {
        writer.write("<div class=\"section\">\n");
        writer.write("<h2>Recomendaciones Estratégicas</h2>\n");
        
        List<String> recomendaciones = analizarYGenerarRecomendaciones(metricas);
        
        for (int i = 0; i < recomendaciones.size(); i++) {
            writer.write("<div class=\"recomendacion\">\n");
            writer.write("<h4>Recomendación " + (i + 1) + "</h4>\n");
            writer.write("<p>" + recomendaciones.get(i) + "</p>\n");
            writer.write("</div>\n");
        }
        
        writer.write("</div>\n");
    }

    private List<String> analizarYGenerarRecomendaciones(List<MetricaRendimiento> metricas) {
        List<String> recomendaciones = new ArrayList<>();
        
        double tiempoPromedioGeneral = metricas.stream()
            .mapToDouble(MetricaRendimiento::getTiempoPromedioMs)
            .average().orElse(0.0);
            
        if (tiempoPromedioGeneral > 2000) {
            recomendaciones.add("Optimización Crítica de Rendimiento: El tiempo de respuesta promedio (" + 
                String.format("%.0f ms", tiempoPromedioGeneral) + ") excede los umbrales aceptables. " +
                "Se recomienda implementar cache Redis y optimizar consultas de base de datos.");
        }
        
        double tasaErrorPromedio = metricas.stream()
            .mapToDouble(MetricaRendimiento::getTasaErrorPorcentaje)
            .average().orElse(0.0);
            
        if (tasaErrorPromedio > 5.0) {
            recomendaciones.add("Control de Errores Urgente: La tasa de error promedio (" + 
                String.format("%.1f%%", tasaErrorPromedio) + ") es inaceptable para producción. " +
                "Implementar circuit breaker y rate limiting.");
        }
        
        if (recomendaciones.isEmpty()) {
            recomendaciones.add("Rendimiento Aceptable: La API muestra un rendimiento dentro de parámetros aceptables. " +
                "Mantener monitoreo continuo y establecer alertas proactivas.");
        }
        
        return recomendaciones;
    }

    private void escrituraConclusiones(BufferedWriter writer, List<MetricaRendimiento> metricas) throws IOException {
        long escenariosCriticos = metricas.stream()
            .filter(m -> m.evaluarNivelRendimiento() == MetricaRendimiento.NivelRendimiento.MALO ||
                        m.evaluarNivelRendimiento() == MetricaRendimiento.NivelRendimiento.INACEPTABLE)
            .count();
            
        String estadoGeneral = escenariosCriticos == 0 ? "APROBADO" : 
                              escenariosCriticos <= metricas.size() / 2 ? "APROBADO CON OBSERVACIONES" : 
                              "REQUIERE CORRECCIONES";
        
        writer.write("<div class=\"section\">\n");
        writer.write("<h2>Conclusiones Finales</h2>\n");
        writer.write("<h3>Estado General del Sistema: " + estadoGeneral + "</h3>\n");
        
        writer.write("<table>\n");
        writer.write("<tr><th>Métrica</th><th>Valor</th></tr>\n");
        writer.write("<tr><td>Total de escenarios</td><td>" + metricas.size() + "</td></tr>\n");
        writer.write("<tr><td>Escenarios críticos</td><td>" + escenariosCriticos + "</td></tr>\n");
        writer.write("<tr><td>Tasa de éxito</td><td>" + 
            String.format("%.1f%%", (double)(metricas.size() - escenariosCriticos) / metricas.size() * 100) + "</td></tr>\n");
        writer.write("</table>\n");
        
        writer.write("</div>\n");
    }

    private void escrituraPieHTML(BufferedWriter writer) throws IOException {
        writer.write("<div style=\"text-align: center; padding: 20px; color: #666;\">\n");
        writer.write("<p>Reporte generado automáticamente por el Framework de Evidencias MediPlus</p>\n");
        writer.write("<p>Autores: Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez</p>\n");
        writer.write("<p>Generado el: " + LocalDateTime.now().format(FORMATO_FECHA) + "</p>\n");
        writer.write("</div>\n");
        writer.write("</div>\n");
        writer.write("</body>\n");
        writer.write("</html>\n");
    }
}