package com.mediplus.pruebas.analisis.servicio;

import java.util.Collections;
import java.util.List;

/**
 * Calculador de estadísticas matemáticas para métricas de rendimiento
 * Implementa Single Responsibility Principle
 * 
 * @author Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez
 */
public class CalculadorEstadisticas {

    /**
     * Calcula el promedio de una lista de valores
     */
    public double calcularPromedio(List<Long> valores) {
        if (valores.isEmpty()) {
            return 0.0;
        }
        return valores.stream().mapToLong(Long::longValue).average().orElse(0.0);
    }

    /**
     * Calcula un percentil específico de una lista de valores
     */
    public double calcularPercentil(List<Long> valores, int percentil) {
        if (valores.isEmpty()) {
            return 0.0;
        }

        if (percentil < 0 || percentil > 100) {
            throw new IllegalArgumentException("El percentil debe estar entre 0 y 100");
        }

        List<Long> valoresOrdenados = valores.stream().sorted().toList();
        int indice = (int) Math.ceil((percentil / 100.0) * valoresOrdenados.size()) - 1;
        indice = Math.max(0, Math.min(indice, valoresOrdenados.size() - 1));

        return valoresOrdenados.get(indice);
    }

    /**
     * Calcula la mediana de una lista de valores
     */
    public double calcularMediana(List<Long> valores) {
        return calcularPercentil(valores, 50);
    }

    /**
     * Calcula la desviación estándar de una lista de valores
     */
    public double calcularDesviacionEstandar(List<Long> valores) {
        if (valores.size() <= 1) {
            return 0.0;
        }

        double promedio = calcularPromedio(valores);
        double sumaCuadrados = valores.stream()
                .mapToDouble(valor -> Math.pow(valor - promedio, 2))
                .sum();

        return Math.sqrt(sumaCuadrados / (valores.size() - 1));
    }

    /**
     * Encuentra outliers usando el método IQR
     */
    public OutliersInfo encontrarOutliers(List<Long> valores) {
        if (valores.size() < 4) {
            return new OutliersInfo(Collections.emptyList(), Collections.emptyList());
        }

        double q1 = calcularPercentil(valores, 25);
        double q3 = calcularPercentil(valores, 75);
        double iqr = q3 - q1;
        double limiteBajo = q1 - 1.5 * iqr;
        double limiteAlto = q3 + 1.5 * iqr;

        List<Long> outliersInferiores = valores.stream()
                .filter(valor -> valor < limiteBajo)
                .toList();

        List<Long> outliersSuperiores = valores.stream()
                .filter(valor -> valor > limiteAlto)
                .toList();

        return new OutliersInfo(outliersInferiores, outliersSuperiores);
    }

    /**
     * Información sobre outliers detectados
     */
    public static class OutliersInfo {
        private final List<Long> outliersInferiores;
        private final List<Long> outliersSuperiores;

        public OutliersInfo(List<Long> outliersInferiores, List<Long> outliersSuperiores) {
            this.outliersInferiores = Collections.unmodifiableList(outliersInferiores);
            this.outliersSuperiores = Collections.unmodifiableList(outliersSuperiores);
        }

        public List<Long> getOutliersInferiores() { return outliersInferiores; }
        public List<Long> getOutliersSuperiores() { return outliersSuperiores; }
        public boolean tieneOutliers() {
            return !outliersInferiores.isEmpty() || !outliersSuperiores.isEmpty();
        }
    }
}