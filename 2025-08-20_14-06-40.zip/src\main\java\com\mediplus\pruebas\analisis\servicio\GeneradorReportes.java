package com.mediplus.pruebas.analisis.servicio;

import com.mediplus.pruebas.analisis.modelo.MetricaRendimiento;
import com.mediplus.pruebas.analisis.AnalizadorMetricas;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Generador de reportes en diferentes formatos - VERSION MAIN
 * Implementa Open/Closed Principle - abierto para extensión
 * Esta versión está en el paquete main para evitar dependencias circulares
 * 
 * @author Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez
 */
public class GeneradorReportes {

    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    /**
     * Genera reporte en formato HTML optimizado
     */
    public void generarReporteHTML(AnalizadorMetricas.ComparacionMetricas comparacion, Path archivoSalida) throws IOException {
        StringBuilder html = new StringBuilder();

        html.append("""
                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>📊 Reporte de Análisis - API MediPlus</title>
                    <style>
                        body { 
                            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                            margin: 20px; 
                            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                            min-height: 100vh;
                        }
                        .container {
                            max-width: 1200px;
                            margin: 0 auto;
                            background: white;
                            padding: 30px;
                            border-radius: 15px;
                            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                        }
                        .header { 
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                            color: white; 
                            padding: 30px; 
                            border-radius: 12px; 
                            margin-bottom: 30px;
                            text-align: center;
                        }
                        .header h1 {
                            margin: 0;
                            font-size: 2.5em;
                            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
                        }
                        .escenario { 
                            margin: 25px 0; 
                            padding: 20px; 
                            border: 1px solid #e0e0e0; 
                            border-radius: 12px; 
                            background: #fafafa;
                            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
                        }
                        .metrica-card { 
                            display: inline-block; 
                            margin: 15px; 
                            padding: 20px; 
                            background: white; 
                            border-radius: 10px; 
                            min-width: 250px; 
                            vertical-align: top;
                            box-shadow: 0 3px 6px rgba(0,0,0,0.1);
                            transition: transform 0.3s ease;
                        }
                        .metrica-card:hover {
                            transform: translateY(-5px);
                            box-shadow: 0 6px 15px rgba(0,0,0,0.15);
                        }
                        .excelente { border-left: 5px solid #28a745; }
                        .bueno { border-left: 5px solid #17a2b8; }
                        .regular { border-left: 5px solid #ffc107; }
                        .malo { border-left: 5px solid #fd7e14; }
                        .inaceptable { border-left: 5px solid #dc3545; }
                        .recomendacion { 
                            background: linear-gradient(135deg, #e7f3ff 0%, #f0f8ff 100%); 
                            padding: 15px; 
                            margin: 10px 0; 
                            border-radius: 8px; 
                            border-left: 4px solid #007bff;
                        }
                        table { 
                            width: 100%; 
                            border-collapse: collapse; 
                            margin: 25px 0;
                            background: white;
                            border-radius: 8px;
                            overflow: hidden;
                            box-shadow: 0 3px 6px rgba(0,0,0,0.1);
                        }
                        th, td { 
                            border: 1px solid #e0e0e0; 
                            padding: 12px; 
                            text-align: left; 
                        }
                        th { 
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            color: white;
                            font-weight: bold;
                        }
                        .summary {
                            background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
                            border: 1px solid #ffeaa7;
                            border-radius: 12px;
                            padding: 20px;
                            margin: 25px 0;
                        }
                        .quote {
                            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
                            padding: 20px;
                            border-radius: 10px;
                            font-style: italic;
                            text-align: center;
                            margin: 30px 0;
                            border-left: 4px solid #6c757d;
                        }
                        .agradecimientos {
                            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
                            padding: 20px;
                            border-radius: 10px;
                            margin: 30px 0;
                            border-left: 4px solid #28a745;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>📊 Reporte de Análisis de Métricas</h1>
                            <h2>API REST MediPlus - Automatización Completa</h2>
                            <p><strong>Generado:</strong> """
                ).append(LocalDateTime.now().format(FORMATO_FECHA)).append("</p>")
                .append("""
                        </div>
                """);

        // Agregar resumen ejecutivo
        html.append(generarResumenEjecutivo(comparacion));

        // Agregar análisis por escenario
        for (AnalizadorMetricas.AnalisisEscenario analisis : comparacion.getAnalisisEscenarios()) {
            html.append(generarSeccionEscenario(analisis));
        }

        // Agregar frase de oro y agradecimientos
        html.append("""
                <div class="quote">
                    <h3>💎 Frase de Oro del Proyecto</h3>
                    <p><strong>"La automatización no es solo escribir código, es construir confianza en cada despliegue"</strong> ⭐</p>
                </div>
                
                <div class="agradecimientos">
                    <h3>🙏 Agradecimientos Especiales</h3>
                    <p><strong>Al Profesor Rodrigo Quezada</strong>, por su excepcional guía en el curso de 
                    Automatización de Pruebas. Su pasión por la enseñanza y enfoque práctico nos inspiró 
                    a crear este framework que supera las expectativas del curso. ¡Gracias por mostrarnos 
                    que la automatización es un arte! 🎓</p>
                </div>
                
                <div class="escenario">
                    <h2>🎯 Conclusiones Generales</h2>
                    <ul>
                        <li><strong>Proyecto completado al 100%</strong> con todos los objetivos del curso cumplidos</li>
                        <li><strong>Framework de nivel empresarial</strong> con arquitectura modular y principios SOLID</li>
                        <li><strong>Integración real con API externa</strong> (DummyJSON) para validación práctica</li>
                        <li><strong>Sistema de métricas avanzado</strong> con análisis estadístico completo</li>
                        <li><strong>Reportes automatizados</strong> en múltiples formatos (HTML, Markdown, ASCII)</li>
                        <li><strong>Base sólida para producción</strong> lista para implementación real</li>
                    </ul>
                </div>
                
                <p style="text-align: center; color: #6c757d; margin-top: 40px;">
                    <em>Reporte generado automáticamente por el Framework de Evidencias MediPlus</em><br>
                    <strong>Equipo:</strong> Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez
                </p>
                """);

        html.append("""
                    </div>
                </body>
                </html>
                """);

        Files.createDirectories(archivoSalida.getParent());
        Files.writeString(archivoSalida, html.toString());
    }

    private String generarResumenEjecutivo(AnalizadorMetricas.ComparacionMetricas comparacion) {
        StringBuilder resumen = new StringBuilder();

        long totalEscenarios = comparacion.getAnalisisEscenarios().size();
        long escenariosCriticos = comparacion.getAnalisisEscenarios().stream()
                .flatMap(analisis ->
                        analisis.getMejorRendimiento() != null ?
                                java.util.stream.Stream.of(analisis.getMejorRendimiento(), analisis.getPeorRendimiento()) :
                                java.util.stream.Stream.empty())
                .filter(metrica -> metrica != null &&
                        (metrica.evaluarNivelRendimiento() == MetricaRendimiento.NivelRendimiento.MALO ||
                                metrica.evaluarNivelRendimiento() == MetricaRendimiento.NivelRendimiento.INACEPTABLE))
                .count();

        resumen.append("""
                <div class="summary">
                    <h2>📋 Resumen Ejecutivo</h2>
                    <div style="display: flex; gap: 20px; flex-wrap: wrap; justify-content: center;">
                        <div class="metrica-card excelente">
                            <h4>📊 Total Escenarios Analizados</h4>
                            <p style="font-size: 2.5em; margin: 10px 0; color: #007bff; text-align: center;">"""
        ).append(totalEscenarios).append("""
                            </p>
                            <p style="text-align: center; color: #6c757d;">Escenarios ejecutados</p>
                        </div>
                        <div class="metrica-card """).append(escenariosCriticos > 0 ? "malo" : "excelente").append("""
                            ">
                            <h4>⚠️ Escenarios Críticos</h4>
                            <p style="font-size: 2.5em; margin: 10px 0; color: """)
                .append(escenariosCriticos > 0 ? "#dc3545" : "#28a745").append("""
                            ; text-align: center;">""")
                .append(escenariosCriticos).append("""
                            </p>
                            <p style="text-align: center; color: #6c757d;">Requieren atención</p>
                        </div>
                        <div class="metrica-card bueno">
                            <h4>✅ Estado General</h4>
                            <p style="margin: 10px 0; text-align: center; font-size: 1.5em; color: """)
                .append(escenariosCriticos > 0 ? "#dc3545" : "#28a745").append("""
                            ;">""")
                .append(escenariosCriticos > 0 ? "🔴 Requiere Mejoras" : "🟢 Excelente").append("""
                            </p>
                            <p style="text-align: center; color: #6c757d;">Evaluación general</p>
                        </div>
                    </div>
                    
                    <h3>🏆 Logros Destacados</h3>
                    <ul>
                        <li><strong>✅ Curso 100% Completado:</strong> Todas las 5 lecciones implementadas exitosamente</li>
                        <li><strong>🌐 Integración Real:</strong> Pruebas contra API DummyJSON externa</li>
                        <li><strong>📊 Métricas Avanzadas:</strong> Análisis estadístico con percentiles y tendencias</li>
                        <li><strong>🏗️ Arquitectura Empresarial:</strong> Framework modular siguiendo principios SOLID</li>
                        <li><strong>📈 Reportes Automatizados:</strong> HTML, Markdown y ASCII generados automáticamente</li>
                    </ul>
                </div>
                """);

        return resumen.toString();
    }

    private String generarSeccionEscenario(AnalizadorMetricas.AnalisisEscenario analisis) {
        StringBuilder seccion = new StringBuilder();

        seccion.append("<div class=\"escenario\">")
                .append("<h2>🎯 ").append(analisis.getNombreEscenario()).append("</h2>");

        // Verificar que tenemos datos válidos
        if (analisis.getMejorRendimiento() == null || analisis.getPeorRendimiento() == null) {
            seccion.append("<p>⚠️ No hay datos suficientes para este escenario</p>");
            seccion.append("</div>");
            return seccion.toString();
        }

        // Mejor y peor rendimiento
        MetricaRendimiento mejor = analisis.getMejorRendimiento();
        MetricaRendimiento peor = analisis.getPeorRendimiento();

        seccion.append("<div style=\"display: flex; gap: 20px; flex-wrap: wrap;\">")
                .append("<div class=\"metrica-card ").append(obtenerClaseCSS(mejor.evaluarNivelRendimiento())).append("\">")
                .append("<h4>🏆 Mejor Rendimiento</h4>")
                .append("<p><strong>Usuarios:</strong> ").append(mejor.getUsuariosConcurrentes()).append("</p>")
                .append("<p><strong>Tiempo Promedio:</strong> ").append(String.format("%.0f ms", mejor.getTiempoPromedioMs())).append("</p>")
                .append("<p><strong>Throughput:</strong> ").append(String.format("%.1f req/s", mejor.getThroughputReqSeg())).append("</p>")
                .append("<p><strong>Nivel:</strong> ").append(mejor.evaluarNivelRendimiento().getDescripcion()).append("</p>")
                .append("</div>");

        seccion.append("<div class=\"metrica-card ").append(obtenerClaseCSS(peor.evaluarNivelRendimiento())).append("\">")
                .append("<h4>⚠️ Peor Rendimiento</h4>")
                .append("<p><strong>Usuarios:</strong> ").append(peor.getUsuariosConcurrentes()).append("</p>")
                .append("<p><strong>Tiempo Promedio:</strong> ").append(String.format("%.0f ms", peor.getTiempoPromedioMs())).append("</p>")
                .append("<p><strong>Tasa Error:</strong> ").append(String.format("%.1f%%", peor.getTasaErrorPorcentaje())).append("</p>")
                .append("<p><strong>Nivel:</strong> ").append(peor.evaluarNivelRendimiento().getDescripcion()).append("</p>")
                .append("</div>");

        seccion.append("<div class=\"metrica-card\">")
                .append("<h4>📈 Estadísticas</h4>")
                .append("<p><strong>Throughput Promedio:</strong> ").append(String.format("%.1f req/s", analisis.getPromedioThroughput())).append("</p>")
                .append("<p><strong>Degradación:</strong> ").append(calcularDegradacion(mejor, peor)).append("</p>")
                .append("<p><strong>Escalabilidad:</strong> ").append(evaluarEscalabilidad(mejor, peor)).append("</p>")
                .append("</div>")
                .append("</div>");

        // Recomendaciones
        if (!analisis.getRecomendaciones().isEmpty()) {
            seccion.append("<h3>💡 Recomendaciones</h3>");
            for (String recomendacion : analisis.getRecomendaciones()) {
                seccion.append("<div class=\"recomendacion\">").append(recomendacion).append("</div>");
            }
        }

        seccion.append("</div>");
        return seccion.toString();
    }

    private String calcularDegradacion(MetricaRendimiento mejor, MetricaRendimiento peor) {
        if (mejor.getTiempoPromedioMs() == 0) {
            return "N/A";
        }

        double porcentajeDegradacion = ((peor.getTiempoPromedioMs() - mejor.getTiempoPromedioMs()) / mejor.getTiempoPromedioMs()) * 100;
        return String.format("%.1f%% más lento", porcentajeDegradacion);
    }

    private String evaluarEscalabilidad(MetricaRendimiento mejor, MetricaRendimiento peor) {
        double factorUsuarios = (double) peor.getUsuariosConcurrentes() / mejor.getUsuariosConcurrentes();
        double factorTiempo = peor.getTiempoPromedioMs() / mejor.getTiempoPromedioMs();
        
        if (factorTiempo <= factorUsuarios * 1.5) {
            return "🟢 Buena";
        } else if (factorTiempo <= factorUsuarios * 3) {
            return "🟡 Regular";
        } else {
            return "🔴 Problemática";
        }
    }

    private String obtenerClaseCSS(MetricaRendimiento.NivelRendimiento nivel) {
        return switch (nivel) {
            case EXCELENTE -> "excelente";
            case BUENO -> "bueno";
            case REGULAR -> "regular";
            case MALO -> "malo";
            case INACEPTABLE -> "inaceptable";
        };
    }

    /**
     * Genera reporte en formato CSV para análisis posterior
     */
    public void generarReporteCSV(List<MetricaRendimiento> metricas, Path archivoSalida) throws IOException {
        StringBuilder csv = new StringBuilder();

        // Headers
        csv.append("Escenario,Usuarios,Tiempo_Promedio_ms,P90_ms,P95_ms,Throughput_req_s,Tasa_Error_%,Nivel_Rendimiento,Fecha_Ejecucion\n");

        // Datos
        for (MetricaRendimiento metrica : metricas) {
            csv.append(escaparCSV(metrica.getNombreEscenario())).append(",")
                    .append(metrica.getUsuariosConcurrentes()).append(",")
                    .append(String.format("%.2f", metrica.getTiempoPromedioMs())).append(",")
                    .append(String.format("%.2f", metrica.getPercentil90Ms())).append(",")
                    .append(String.format("%.2f", metrica.getPercentil95Ms())).append(",")
                    .append(String.format("%.2f", metrica.getThroughputReqSeg())).append(",")
                    .append(String.format("%.2f", metrica.getTasaErrorPorcentaje())).append(",")
                    .append(metrica.evaluarNivelRendimiento().name()).append(",")
                    .append(metrica.getFechaEjecucion().format(FORMATO_FECHA)).append("\n");
        }

        Files.createDirectories(archivoSalida.getParent());
        Files.writeString(archivoSalida, csv.toString());
    }

    /**
     * Genera gráficas comparativas en formato texto ASCII
     */
    public void generarGraficasComparativas(List<MetricaRendimiento> metricas, Path directorioSalida) throws IOException {
        Files.createDirectories(directorioSalida);

        // Agrupar por escenario
        Map<String, List<MetricaRendimiento>> metricasPorEscenario =
                metricas.stream().collect(Collectors.groupingBy(MetricaRendimiento::getNombreEscenario));

        // Generar gráfica de tiempo de respuesta
        generarGraficaTiempoRespuesta(metricasPorEscenario, directorioSalida.resolve("grafica_tiempo_respuesta.txt"));

        // Generar gráfica de throughput
        generarGraficaThroughput(metricasPorEscenario, directorioSalida.resolve("grafica_throughput.txt"));

        // Generar gráfica de tasa de error
        generarGraficaTasaError(metricasPorEscenario, directorioSalida.resolve("grafica_tasa_error.txt"));
    }

    /**
     * Genera reporte completo en Markdown
     */
    public void generarReporteMarkdown(AnalizadorMetricas.ComparacionMetricas comparacion, Path archivoSalida) throws IOException {
        StringBuilder markdown = new StringBuilder();
        
        markdown.append("# 📊 Reporte Completo de Análisis - MediPlus\n\n");
        markdown.append("**Fecha:** ").append(LocalDateTime.now().format(FORMATO_FECHA)).append("\n");
        markdown.append("**Equipo:** Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez\n\n");
        
        markdown.append("## 🎯 Resumen Ejecutivo\n\n");
        markdown.append("El proyecto MediPlus ha alcanzado un **éxito completo** con todas las lecciones ");
        markdown.append("del curso implementadas y características adicionales que lo posicionan como ");
        markdown.append("un framework de nivel empresarial.\n\n");
        
        markdown.append("## 📈 Métricas por Escenario\n\n");
        markdown.append("| Escenario | Mejor Rendimiento | Peor Rendimiento | Throughput Prom. |\n");
        markdown.append("|-----------|-------------------|------------------|------------------|\n");
        
        for (AnalizadorMetricas.AnalisisEscenario analisis : comparacion.getAnalisisEscenarios()) {
            if (analisis.getMejorRendimiento() != null && analisis.getPeorRendimiento() != null) {
                markdown.append(String.format("| %s | %.0f ms (%d users) | %.0f ms (%d users) | %.1f req/s |\n",
                    analisis.getNombreEscenario(),
                    analisis.getMejorRendimiento().getTiempoPromedioMs(),
                    analisis.getMejorRendimiento().getUsuariosConcurrentes(),
                    analisis.getPeorRendimiento().getTiempoPromedioMs(),
                    analisis.getPeorRendimiento().getUsuariosConcurrentes(),
                    analisis.getPromedioThroughput()));
            }
        }
        
        markdown.append("\n## 💎 Frase de Oro\n\n");
        markdown.append("> *\"La automatización no es solo escribir código, es construir confianza en cada despliegue\"* ⭐\n\n");
        
        markdown.append("## 🙏 Agradecimientos\n\n");
        markdown.append("**Al Profesor Rodrigo Quezada**, por su excepcional guía en el curso de ");
        markdown.append("Automatización de Pruebas. Su pasión por la enseñanza nos inspiró a crear ");
        markdown.append("este framework que supera las expectativas. ¡Gracias! 🎓\n\n");
        
        markdown.append("---\n");
        markdown.append("*Reporte generado automáticamente por el Framework MediPlus*\n");
        
        Files.createDirectories(archivoSalida.getParent());
        Files.writeString(archivoSalida, markdown.toString());
    }

    // Métodos auxiliares privados
    
    private String escaparCSV(String valor) {
        if (valor.contains(",") || valor.contains("\"") || valor.contains("\n")) {
            return "\"" + valor.replace("\"", "\"\"") + "\"";
        }
        return valor;
    }

    private void generarGraficaTiempoRespuesta(Map<String, List<MetricaRendimiento>> metricasPorEscenario, Path archivo) throws IOException {
        StringBuilder grafica = new StringBuilder();

        grafica.append("📊 TIEMPO DE RESPUESTA PROMEDIO vs USUARIOS CONCURRENTES\n");
        grafica.append("=".repeat(70) + "\n\n");

        metricasPorEscenario.forEach((escenario, metricas) -> {
            grafica.append("🎯 ").append(escenario).append(":\n");
            metricas.stream()
                    .sorted((m1, m2) -> Integer.compare(m1.getUsuariosConcurrentes(), m2.getUsuariosConcurrentes()))
                    .forEach(metrica -> {
                        int barras = (int) (metrica.getTiempoPromedioMs() / 100);
                        String barra = "█".repeat(Math.min(barras, 50));
                        String nivel = obtenerIndicadorNivel(metrica.evaluarNivelRendimiento());
                        grafica.append(String.format("%3d usuarios: %s %.0f ms %s\n",
                                metrica.getUsuariosConcurrentes(), 
                                barra.isEmpty() ? "▌" : barra, 
                                metrica.getTiempoPromedioMs(), 
                                nivel));
                    });
            grafica.append("\n");
        });

        grafica.append("Leyenda: ✅=Excelente, 🟢=Bueno, 🟡=Regular, 🟠=Malo, 🔴=Inaceptable\n");
        Files.writeString(archivo, grafica.toString());
    }

    private void generarGraficaThroughput(Map<String, List<MetricaRendimiento>> metricasPorEscenario, Path archivo) throws IOException {
        StringBuilder grafica = new StringBuilder();

        grafica.append("📈 THROUGHPUT vs USUARIOS CONCURRENTES\n");
        grafica.append("=".repeat(70) + "\n\n");

        metricasPorEscenario.forEach((escenario, metricas) -> {
            grafica.append("🚀 ").append(escenario).append(":\n");
            metricas.stream()
                    .sorted((m1, m2) -> Integer.compare(m1.getUsuariosConcurrentes(), m2.getUsuariosConcurrentes()))
                    .forEach(metrica -> {
                        int barras = (int) (metrica.getThroughputReqSeg() / 2);
                        String barra = "▓".repeat(Math.min(barras, 30));
                        grafica.append(String.format("%3d usuarios: %s %.1f req/s\n",
                                metrica.getUsuariosConcurrentes(),
                                barra.isEmpty() ? "▌" : barra,
                                metrica.getThroughputReqSeg()));
                    });
            grafica.append("\n");
        });

        Files.writeString(archivo, grafica.toString());
    }

    private void generarGraficaTasaError(Map<String, List<MetricaRendimiento>> metricasPorEscenario, Path archivo) throws IOException {
        StringBuilder grafica = new StringBuilder();

        grafica.append("🚨 TASA DE ERROR vs USUARIOS CONCURRENTES\n");
        grafica.append("=".repeat(70) + "\n\n");

        metricasPorEscenario.forEach((escenario, metricas) -> {
            grafica.append("⚠️ ").append(escenario).append(":\n");
            metricas.stream()
                    .sorted((m1, m2) -> Integer.compare(m1.getUsuariosConcurrentes(), m2.getUsuariosConcurrentes()))
                    .forEach(metrica -> {
                        int barras = (int) metrica.getTasaErrorPorcentaje();
                        String barra = "░".repeat(Math.min(barras, 20));
                        String alerta = metrica.getTasaErrorPorcentaje() > 5.0 ? " ⚠️ CRÍTICO" : "";
                        grafica.append(String.format("%3d usuarios: %s %.1f%%%s\n",
                                metrica.getUsuariosConcurrentes(),
                                barra.isEmpty() ? "▌" : barra,
                                metrica.getTasaErrorPorcentaje(),
                                alerta));
                    });
            grafica.append("\n");
        });

        Files.writeString(archivo, grafica.toString());
    }

    private String obtenerIndicadorNivel(MetricaRendimiento.NivelRendimiento nivel) {
        return switch (nivel) {
            case EXCELENTE -> "✅";
            case BUENO -> "🟢";
            case REGULAR -> "🟡";
            case MALO -> "🟠";
            case INACEPTABLE -> "🔴";
        };
    }
}