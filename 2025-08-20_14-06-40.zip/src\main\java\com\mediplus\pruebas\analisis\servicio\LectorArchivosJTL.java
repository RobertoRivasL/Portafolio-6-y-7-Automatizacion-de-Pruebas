package com.mediplus.pruebas.analisis.servicio;

import com.mediplus.pruebas.analisis.modelo.MetricaRendimiento;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Responsable de leer y procesar archivos JTL de JMeter
 * Implementa Single Responsibility Principle
 * 
 * @author Antonio B. Arriagada LL., Dante Escalona Bustos, Roberto Rivas Lopez
 */
public class LectorArchivosJTL {

    private static final Pattern PATRON_NOMBRE_ARCHIVO =
            Pattern.compile("(\\w+)_(\\d+)u\\.jtl");

    /**
     * Procesa un archivo JTL y extrae las métricas de rendimiento
     */
    public MetricaRendimiento procesarArchivoJTL(Path archivoJtl) throws IOException {
        String nombreArchivo = archivoJtl.getFileName().toString();
        String nombreEscenario = extraerNombreEscenario(nombreArchivo);
        int usuariosConcurrentes = extraerUsuariosConcurrentes(nombreArchivo);

        List<String> lineas = Files.readAllLines(archivoJtl);
        List<RegistroJTL> registros = procesarLineasJTL(lineas);

        if (registros.isEmpty()) {
            System.err.println("⚠️ No se encontraron registros válidos en: " + nombreArchivo);
            return null;
        }

        return calcularMetricas(nombreEscenario, usuariosConcurrentes, registros);
    }

    private String extraerNombreEscenario(String nombreArchivo) {
        // Patrones posibles:
        // get_masivo_10u.jtl -> GET Masivo
        // post_masivo_50u_2024-08-18_15-30-00.jtl -> POST Masivo
        // mixto_100u.jtl -> GET+POST Combinado
        
        if (nombreArchivo.contains("get_masivo") || nombreArchivo.contains("get-masivo")) {
            return "GET Masivo";
        } else if (nombreArchivo.contains("post_masivo") || nombreArchivo.contains("post-masivo")) {
            return "POST Masivo";
        } else if (nombreArchivo.contains("mixto") || nombreArchivo.contains("combinadas")) {
            return "GET+POST Combinado";
        }
        
        // Fallback: usar el patrón regex
        Matcher matcher = PATRON_NOMBRE_ARCHIVO.matcher(nombreArchivo);
        if (matcher.find()) {
            return formatearNombreEscenario(matcher.group(1));
        }
        
        return "Escenario Desconocido";
    }

    private String formatearNombreEscenario(String nombre) {
        return switch (nombre.toLowerCase()) {
            case "get_masivo", "get-masivo" -> "GET Masivo";
            case "post_masivo", "post-masivo" -> "POST Masivo";
            case "mixto", "combinadas" -> "GET+POST Combinado";
            default -> nombre.substring(0, 1).toUpperCase() + nombre.substring(1);
        };
    }

    private int extraerUsuariosConcurrentes(String nombreArchivo) {
        // Buscar patrón como: _10u, _50u, _100u
        Pattern patronUsuarios = Pattern.compile("_(\\d+)u");
        Matcher matcher = patronUsuarios.matcher(nombreArchivo);
        
        if (matcher.find()) {
            return Integer.parseInt(matcher.group(1));
        }
        
        // Fallback: buscar cualquier número en el nombre
        Pattern patronNumero = Pattern.compile("(\\d+)");
        Matcher matcherNumero = patronNumero.matcher(nombreArchivo);
        
        if (matcherNumero.find()) {
            int numero = Integer.parseInt(matcherNumero.group(1));
            // Si es un número razonable para usuarios concurrentes
            if (numero >= 1 && numero <= 1000) {
                return numero;
            }
        }
        
        return 1; // Valor por defecto
    }

    private List<RegistroJTL> procesarLineasJTL(List<String> lineas) {
        List<RegistroJTL> registros = new ArrayList<>();

        // Determinar si la primera línea es header
        int inicioLineas = (lineas.size() > 0 && lineas.get(0).contains("timeStamp")) ? 1 : 0;

        for (int i = inicioLineas; i < lineas.size(); i++) {
            String linea = lineas.get(i);
            try {
                RegistroJTL registro = parsearLineaJTL(linea);
                if (registro != null) {
                    registros.add(registro);
                }
            } catch (Exception e) {
                System.err.println("⚠️ Error procesando línea " + (i + 1) + ": " + e.getMessage());
            }
        }

        return registros;
    }

    private RegistroJTL parsearLineaJTL(String linea) {
        String[] campos = linea.split(",");
        
        // Formato JTL estándar requiere al menos 10 campos
        if (campos.length < 10) {
            return null;
        }

        try {
            return new RegistroJTL(
                    Long.parseLong(campos[0]),          // timeStamp
                    Long.parseLong(campos[1]),          // elapsed (tiempo de respuesta)
                    campos[2],                          // label
                    Integer.parseInt(campos[3]),        // responseCode
                    campos[4],                          // responseMessage
                    "true".equals(campos[7]),           // success
                    campos.length > 9 ? Long.parseLong(campos[9]) : 0  // bytes
            );
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private MetricaRendimiento calcularMetricas(String nombreEscenario, int usuariosConcurrentes,
                                                List<RegistroJTL> registros) {
        
        CalculadorEstadisticas calculador = new CalculadorEstadisticas();

        List<Long> tiemposRespuesta = registros.stream()
                .map(RegistroJTL::getTiempoRespuestaMs)
                .toList();

        long errores = registros.stream()
                .mapToLong(r -> r.fueExitoso() ? 0 : 1)
                .sum();

        // Calcular duración total de la prueba
        long tiempoInicioMs = registros.stream()
                .mapToLong(RegistroJTL::getTiempoInicioMs)
                .min()
                .orElse(System.currentTimeMillis());
                
        long tiempoFinMs = registros.stream()
                .mapToLong(RegistroJTL::getTiempoInicioMs)
                .max()
                .orElse(System.currentTimeMillis());
                
        long duracionTotalMs = tiempoFinMs - tiempoInicioMs;
        long duracionSegundos = Math.max(1, duracionTotalMs / 1000);

        double throughput = (double) registros.size() / duracionSegundos;
        double tasaError = (double) errores / registros.size() * 100.0;

        return new MetricaRendimiento.Builder()
                .nombreEscenario(nombreEscenario)
                .usuariosConcurrentes(usuariosConcurrentes)
                .tiempoPromedioMs(calculador.calcularPromedio(tiemposRespuesta))
                .percentil90Ms(calculador.calcularPercentil(tiemposRespuesta, 90))
                .percentil95Ms(calculador.calcularPercentil(tiemposRespuesta, 95))
                .throughputReqSeg(throughput)
                .tasaErrorPorcentaje(tasaError)
                .tiempoMinimoMs(Collections.min(tiemposRespuesta))
                .tiempoMaximoMs(Collections.max(tiemposRespuesta))
                .duracionPruebaSegundos((int) duracionSegundos)
                .fechaEjecucion(LocalDateTime.now())
                .build();
    }

    /**
     * Clase interna para representar un registro del archivo JTL
     */
    private static class RegistroJTL {
        private final long tiempoInicioMs;
        private final long tiempoRespuestaMs;
        private final String etiqueta;
        private final int codigoRespuesta;
        private final String mensajeRespuesta;
        private final boolean exitoso;
        private final long bytes;

        public RegistroJTL(long tiempoInicioMs, long tiempoRespuestaMs, String etiqueta,
                           int codigoRespuesta, String mensajeRespuesta, boolean exitoso, long bytes) {
            this.tiempoInicioMs = tiempoInicioMs;
            this.tiempoRespuestaMs = tiempoRespuestaMs;
            this.etiqueta = etiqueta;
            this.codigoRespuesta = codigoRespuesta;
            this.mensajeRespuesta = mensajeRespuesta;
            this.exitoso = exitoso;
            this.bytes = bytes;
        }

        // Getters
        public long getTiempoInicioMs() { return tiempoInicioMs; }
        public long getTiempoRespuestaMs() { return tiempoRespuestaMs; }
        public String getEtiqueta() { return etiqueta; }
        public int getCodigoRespuesta() { return codigoRespuesta; }
        public String getMensajeRespuesta() { return mensajeRespuesta; }
        public boolean fueExitoso() { return exitoso; }
        public long getBytes() { return bytes; }
    }
}